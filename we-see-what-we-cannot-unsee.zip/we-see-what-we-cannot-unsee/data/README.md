# Data

No raw data is stored here. All four datasets are public; get them from their sources and follow each one's license and citation terms.

| Dataset | Used for | File(s) the scripts read | Source |
|---|---|---|---|
| Hippocorpus (Sap et al., 2020) | Importance ratings that change on retelling; the H6 attempt | `hcV3-stories.csv` | [Microsoft Research download](https://www.microsoft.com/en-us/download/details.aspx?id=105291) |
| MainLife (Peters et al., 2023) | Meaning revised over four years | `mainlife_data/Data for MLMs of change in AM.xlsx` | Supporting information of [Peters et al., 2023, *Journal of Personality*](https://doi.org/10.1111/jopy.12793) |
| Experience sampling of meaning and affect (Gainey et al.) | Feeling and meaning; getting things done | `0058_gainey_ts.tsv` | openESM database, dataset `0058_gainey` |
| Goal-shelving diary (Mayer & Freund, 2025) | Significance and attention; the way back | `diarydt.csv` | [OSF project 4ptmx](https://osf.io/4ptmx) |

The goal-diary data ships as R data; `diarydt.csv` is a plain CSV export of the `diarydt` table.
