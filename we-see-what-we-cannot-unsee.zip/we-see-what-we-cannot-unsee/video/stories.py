"""Companion video: four short stories, tied back to 'We see what we cannot unsee'. Written by Claude.
Usage: python3 stories.py still <scene> <t> <out.png> | render <scene> <outdir> | list"""
import sys, os, subprocess
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lv_common import *
from lv_part1 import partcard

# ---------- drawing helpers ----------
def person(f, x, y, s, col, a=1.0):
    if a <= 0: return
    c = mix(BG, col, a)
    f.circle(x, y - 1.75 * s, 0.72 * s, fill=c)
    f.rect(x - 1.0 * s, y - 0.85 * s, x + 1.0 * s, y + 1.3 * s, c, r=0.9 * s)

def bubble(f, x0, y0, x1, y1, tail, s, a, col=WHITE, size=32):
    if a <= 0: return
    f.poly([(x0 + 40, y1 - 2), (x0 + 90, y1 - 2), tail], fill=mix(BG, col, 0.12 * a))
    f.rect(x0, y0, x1, y1, mix(BG, col, 0.12 * a), r=18, outline=mix(BG, col, a), w=3)
    f.line([(x0 + 40, y1), tail, (x0 + 90, y1)], mix(BG, col, a), 3)
    f.text(((x0 + x1) / 2, (y0 + y1) / 2), s, size, col, a, fk="I")

CHAIR = [((-0.6, 1.1), (-0.6, 0.0)), ((0.5, 1.1), (0.52, 0.0)), ((-0.72, 0.0), (0.58, 0.0)), ((-0.6, 0.65), (0.51, 0.65)),
         ((0.52, 0.0), (0.62, -1.3)), ((0.4, -0.25), (0.48, -1.2)), ((0.48, -1.2), (0.62, -1.3)), ((0.4, -0.25), (0.53, -0.1))]
JOINTS = [(-0.6, 0.0), (0.52, 0.0), (-0.6, 0.65), (0.51, 0.65), (0.62, -1.3), (0.48, -1.2), (0.4, -0.25), (0.53, -0.1)]
def chair(f, cx, cy, s, col, w=6, upto=8.0, a=1.0):
    c = mix(BG, col, a)
    for k, ((x0, y0), (x1, y1)) in enumerate(CHAIR):
        p = clamp(upto - k)
        if p > 0: f.line(partial([(cx + x0 * s, cy + y0 * s), (cx + x1 * s, cy + y1 * s)], p), c, w + (4 if k == 2 else 0))

def guitar(f, cx, cy, s, col, a=1.0):
    if a <= 0: return
    c = mix(BG, col, a)
    f.rect(cx - 0.08 * s, cy - 1.7 * s, cx + 0.08 * s, cy - 0.2 * s, c, r=2)
    f.rect(cx - 0.14 * s, cy - 1.95 * s, cx + 0.14 * s, cy - 1.6 * s, c, r=4)
    f.circle(cx, cy + 0.45 * s, 0.55 * s, fill=c); f.circle(cx, cy - 0.15 * s, 0.42 * s, fill=c)
    f.circle(cx, cy + 0.1 * s, 0.14 * s, fill=BG)

def house(f, x, y, s, col, a=1.0):
    if a <= 0: return
    c = mix(BG, col, a)
    f.poly([(x - s, y + s), (x - s, y - 0.2 * s), (x, y - s), (x + s, y - 0.2 * s), (x + s, y + s)], outline=c, w=3)

def table(f, cx, cy, w, h, n, col, a=1.0, seat_cols=None):
    if a <= 0: return []
    f.rect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, mix(BG, WHITE, 0.06 * a), r=16, outline=mix(BG, GREY, 0.7 * a), w=2)
    pts = []
    for k in range(n):
        side = -1 if k % 2 == 0 else 1; i = k // 2; m = max(1, (n + 1) // 2)
        x = cx - w / 2 + w * (i + 0.5) / m; y = cy + side * (h / 2 + 22)
        pts.append((x, y)); c = (seat_cols[k] if seat_cols else mix(BG, GREY, 0.8))
        f.circle(x, y, 15, fill=mix(BG, c, a))
    return pts

def story_header(f, s): f.text((56, 44), s, 26, GREY, anchor="lm", fk="I")

def tie(num, lines, callback, chips):
    def fn(t, f):
        story_header(f, f"Story {num}: what this shows")
        f.text((960, 170), "What this shows", 40, YELLOW, prog(t, 0.2, 0.7), fk="I")
        for k, s in enumerate(lines):
            para(f, (960, 300 + 100 * k), s, 46, WHITE, maxw=1600, write=ease(prog(t, 0.8 + 1.8 * k, 2.4 + 1.8 * k)))
        y0 = 300 + 100 * len(lines) + 60
        para(f, (960, y0), callback, 50, TEAL, prog(t, 1.0 + 1.8 * len(lines), 1.7 + 1.8 * len(lines)), maxw=1600, fk="I")
        ts = 2.4 + 1.8 * len(lines)
        f.text((960, y0 + 140), "We see what we cannot unsee.", 56, YELLOW, write=ease(prog(t, ts, ts + 1.4)))
        ws = [chip_w(c, 28) for c in chips]; x = 960 - (sum(ws) + 30 * (len(ws) - 1)) / 2
        for c, w in zip(chips, ws):
            chip(f, x, y0 + 280, c, GREY, prog(t, ts + 1.6, ts + 2.2), size=28); x += w + 30
    return fn

# ---------- scenes ----------
def s_open(t, f):
    f.text((960, 420), "We see what we cannot unsee", 96, WHITE, write=ease(prog(t, 0.3, 1.9)))
    f.text((960, 530), "four short stories", 46, GREY, prog(t, 1.8, 2.5), fk="I")
    pts = wiggle(400, 1520, 760, 36); p = ease(prog(t, 2.2, 5.8)); f.line(partial(pts, p), BLUE, 5)
    for u, r, c in [(0.14, 14, TEAL), (0.38, 14, BLUE), (0.62, 14, PURPLE), (0.86, 14, GOLD)]:
        if p >= u:
            q = pts[int(u * (len(pts) - 1))]; f.glow(q[0], q[1], r * back(prog(t, 2.2 + 3.6 * u, 2.6 + 3.6 * u)), c)
    f.text((960, 900), "The stories are made up. The pattern in them is the idea.", 30, GREY, prog(t, 4.6, 5.3), fk="I")
S_OPEN = (s_open, 8.5)

# Story 1
X1 = lambda age: 330 + (age - 14) / 20 * 1420
def s_st1(t, f):
    story_header(f, "Story 1: The ten-minute conversation")
    person(f, 160, 470, 30, TEAL, prog(t, 0.3, 0.8)); f.text((160, 540), "Asha", 34, TEAL, prog(t, 0.5, 1.0))
    ty = 700; a = ease(prog(t, 0.6, 2.0))
    if a > 0:
        f.line([(X1(14), ty), (X1(14) + (X1(34) - X1(14)) * a, ty)], GREY, 3)
        for age in range(14, 35, 4):
            if X1(age) <= X1(14) + (X1(34) - X1(14)) * a:
                f.line([(X1(age), ty - 8), (X1(age), ty + 8)], GREY, 2); f.text((X1(age), ty + 36), ("age " if age == 14 else "") + str(age), 26, GREY, 1, fk="I")
    # the conversation
    ba = win(t, 2.6, 11.0)
    person(f, X1(15), 430, 22, WHITE, ba); f.text((X1(15), 485), "a teacher", 26, GREY, ba, fk="I")
    bubble(f, X1(15) + 60, 270, X1(15) + 680, 370, (X1(15) + 20, 390), "You notice things like a scientist.", ba)
    ca = prog(t, 3.0, 3.6)
    if ca > 0: f.line([(X1(15), ty - 16), (X1(15), ty + 16)], mix(BG, TEAL, ca), 6)
    f.text((X1(15), ty - 40), "10 minutes", 28, TEAL, ca, fk="I")
    # the degree
    da = ease(prog(t, 7.0, 8.6))
    if da > 0: f.rect(X1(18), ty - 12, X1(18) + (X1(22) - X1(18)) * da, ty + 12, mix(BG, GOLD, 0.55), r=6)
    f.text(((X1(18) + X1(22)) / 2, ty - 40), "a four-year degree in accounting", 28, GOLD, prog(t, 8.0, 8.6), fk="I")
    # years pass: echoes
    age = 15 + 19 * ease(prog(t, 11.6, 23.0))
    if 11.6 < t < 24:
        f.glow(X1(age), ty, 7, WHITE)
    echoes = [(19, "19: spots a pattern no one else saw"), (25, "25: asks to join a research team"), (30, "30: becomes a researcher")]
    R = 9; dy = 560
    for k, (ea, lab) in enumerate(echoes):
        te = 11.6 + (ea - 15) / 19 * 11.4
        if t >= te:
            u = clamp((t - te) / 1.4); R += 12 * ease(u)
            f.text((X1(ea), ty + 80 + 40 * (k % 2)), lab, 26, WHITE, prog(t, te, te + 0.5), fk="I")
            if u < 1:
                arc = bez((X1(ea), ty - 10), (X1(ea), dy - 60), (X1(15) + 60, dy - 60), (X1(15), dy), 30)
                f.line(partial(arc, ease(u)), mix(BG, TEAL, 1 - u * 0.5), 3)
                ring(f, X1(15), dy, R + 30 * u, TEAL, 1 - u, 3)
    if t > 2.8: f.glow(X1(15), dy, R * back(prog(t, 3.2, 3.8)), TEAL)
    Rd = 12 - 3 * ease(prog(t, 14, 22))
    if t > 8.4: f.glow(X1(20), dy, Rd * back(prog(t, 8.6, 9.2)), GOLD)
    f.text((X1(15) + 70, dy - 75), "the conversation", 30, TEAL, prog(t, 24.0, 24.6), anchor="lm", fk="I")
    f.text((X1(20) + 30, dy - 30), "the degree", 30, GOLD, prog(t, 24.3, 24.9), anchor="lm", fk="I")
    f.text((960, 420), "dot size: how much it shapes how she sees things", 30, GREY, prog(t, 24.6, 25.2), fk="I")
    cap(f, "At 15, a teacher spends ten minutes with Asha.", win(t, 1.0, 6.6), y=975)
    cap(f, "At 18, she starts a four-year degree in accounting.", win(t, 6.8, 11.4), y=975)
    cap(f, "Years pass. Again and again, something new echoes that one conversation.", win(t, 11.6, 23.6), y=975)
    cap(f, "At 34: the four years barely shape her. The ten minutes still do.", prog(t, 24.0, 24.8), y=975, col=YELLOW)
S_ST1 = (s_st1, 33.0)
S_C1 = partcard("Story 1", "The ten-minute conversation", "how long it lasted vs. how much it mattered")
S_T1 = (tie(1, ["How long something lasted did not decide how much it mattered.", "And its meaning grew after it was over, each time a new moment echoed it."],
            "Every puzzle now looks to her like a question she is allowed to ask. She cannot unsee it.",
            ["H2: duration is not meaning", "H3: meaning keeps changing"]), 13.0)

# Story 2
def s_st2(t, f):
    story_header(f, "Story 2: The chair")
    person(f, 150, 450, 30, BLUE, prog(t, 0.3, 0.8)); f.text((150, 520), "Sam", 34, BLUE, prog(t, 0.5, 1.0))
    person(f, 150, 720, 30, GREY, prog(t, 0.6, 1.1)); f.text((150, 790), "Kai, his friend", 30, GREY, prog(t, 0.8, 1.3))
    a1 = win(t, 1.0, 8.2)
    if a1 > 0:
        chair(f, 960, 520, 150, GREY, 6, upto=8 * ease(prog(t, 1.2, 2.6)), a=a1)
        f.text((960, 260), "a chair", 40, GREY, a1, fk="I")
    a2 = win(t, 8.4, 17.6)
    if a2 > 0:
        up = 8 * prog(t, 9.2, 15.6)
        chair(f, 960, 520, 150, BLUE, 6, upto=up, a=a2)
        for k, (jx, jy) in enumerate(JOINTS):
            if up > [0, 1, 0, 3, 4, 5, 6, 7][k] + 1:
                f.glow(960 + jx * 150, 520 + jy * 150, 8 * a2, YELLOW)
        chip(f, 1500, 260, "one weekend", BLUE, a2, size=32)
    a3 = prog(t, 17.8, 18.6)
    if a3 > 0:
        L, Rr = (640, 600), (1340, 600); s = 125
        f.text((L[0], 290), "what Kai sees", 34, GREY, a3, fk="I"); f.text((Rr[0], 290), "what Sam sees", 34, BLUE, a3, fk="I")
        chair(f, L[0], L[1], s, GREY, 5, a=a3); chair(f, Rr[0], Rr[1], s, GREY, 5, a=a3)
        f.text((L[0], L[1] - s * 1.3 - 50), "a chair", 32, GREY, prog(t, 19.0, 19.6), fk="I")
        ja = prog(t, 20.0, 21.0)
        for jx, jy in JOINTS: f.glow(Rr[0] + jx * s, Rr[1] + jy * s, 8 * ja, YELLOW)
        notes = [((-0.6, 0.65), (1040, 760), "this leg wobbles", 21.6), ((0.52, 0.0), (1620, 560), "glued, not jointed", 22.6), ((-0.1, 0.0), (1040, 470), "nice grain", 23.6)]
        for (jx, jy), (tx, ty_), lab, ts in notes:
            na = prog(t, ts, ts + 0.6)
            if na > 0:
                px, py = Rr[0] + jx * s, Rr[1] + jy * s
                f.line([(px, py), (tx, ty_)], mix(BG, YELLOW, 0.6 * na), 2)
                f.text((tx + (12 if tx > px else -12), ty_), lab, 30, YELLOW, na, anchor="lm" if tx > px else "rm", fk="I")
    cap(f, "Sam walks past hundreds of chairs. To him, they are just chairs.", win(t, 1.0, 8.2), y=975)
    cap(f, "Then he spends one weekend building a chair himself, joint by joint.", win(t, 8.6, 17.6), y=975)
    cap(f, "Months later, he and Kai stop at the same chair in a store.", win(t, 17.8, 24.6), y=975)
    cap(f, "Kai sees a chair. Sam sees every joint.", prog(t, 24.8, 25.5), y=975, col=YELLOW)
S_ST2 = (s_st2, 31.0)
S_C2 = partcard("Story 2", "The chair", "when an experience becomes a lens")
S_T2 = (tie(2, ["The weekend did not just leave a memory. It became a lens.", "Anything that resembles it is now seen through it."],
            "He cannot look at a chair without seeing the joints. He cannot unsee them.",
            ["H6: the past changes how the new is seen"]), 12.5)

# Story 3
TABLES = [(760, 380, 6), (1160, 380, 6), (760, 650, 6), (1160, 650, 6)]
LONE = (1600, 515)
def s_st3(t, f):
    story_header(f, "Story 3: The new kid at lunch")
    pa = prog(t, 0.3, 0.9)
    person(f, 120, 330, 26, PURPLE, pa); f.text((120, 392), "Lena", 32, PURPLE, pa)
    for k in range(5): house(f, 210 + 52 * k, 330, 18, PURPLE, prog(t, 1.0 + 0.2 * k, 1.3 + 0.2 * k))
    f.text((330, 385), "moved schools five times", 26, GREY, prog(t, 2.0, 2.5), fk="I")
    person(f, 120, 600, 26, TEAL, pa); f.text((120, 662), "Jay", 32, TEAL, pa)
    house(f, 210, 600, 18, TEAL, prog(t, 1.2, 1.5)); f.text((330, 655), "same school since age 5", 26, GREY, prog(t, 2.2, 2.7), fk="I")
    ra = prog(t, 2.6, 3.6) * (1 - prog(t, 18.4, 19.2))
    lena = jay = None; friends = []
    if ra > 0:
        f.rect(540, 230, 1800, 820, None, r=24, outline=mix(BG, DIM, ra), w=2)
        f.text((1170, 205), "the lunchroom", 26, GREY, ra, fk="I")
        for k, (cx, cy, n) in enumerate(TABLES):
            cols = None
            if k == 2: cols = [PURPLE, TEAL, GREY, GREY, GREY, GREY]
            pts = table(f, cx, cy, 280, 110, n, GREY, ra, cols)
            if k == 2: lena, jay = pts[0], pts[1]
            if k == 3: friends = pts[:3]
        f.rect(LONE[0] - 110, LONE[1] - 55, LONE[0] + 110, LONE[1] + 55, mix(BG, WHITE, 0.06 * ra), r=16, outline=mix(BG, GREY, 0.7 * ra), w=2)
        lone = (LONE[0], LONE[1] + 77)
        g1 = ease(prog(t, 8.4, 9.6)) * ra
        if g1 > 0 and jay:
            for q in friends: f.line([jay, (jay[0] + (q[0] - jay[0]) * g1, jay[1] + (q[1] - jay[1]) * g1)], mix(BG, TEAL, 0.8), 3)
        g2 = ease(prog(t, 12.6, 14.0)) * ra
        if g2 > 0 and lena:
            f.line([lena, (lena[0] + (lone[0] - lena[0]) * g2, lena[1] + (lone[1] - lena[1]) * g2)], PURPLE, 7)
        f.glow(lone[0], lone[1], (15 + 8 * g2) * ra, mix(GREY, WHITE, g2))
        f.text((lone[0], lone[1] + 50), "new kid", 26, WHITE, ra * prog(t, 3.4, 3.9), fk="I")
    wa = prog(t, 19.0, 19.8)
    if wa > 0:
        f.text((1170, 260), "Lena's lunches, week by week", 34, WHITE, wa)
        shares = [0.0, 0.1, 0.2, 0.3, 0.35, 0.4]
        for k, s in enumerate(shares):
            ba = ease(prog(t, 19.8 + 0.9 * k, 20.6 + 0.9 * k)); x = 700 + 190 * k; h = 400 * ba
            if h > 1:
                f.rect(x - 60, 760 - h, x + 60, 760, mix(BG, PURPLE, 0.35), r=6)
                if s > 0: f.rect(x - 60, 760 - h * s, x + 60, 760, mix(BG, WHITE, 0.75), r=6)
            f.text((x, 795), f"week {k + 1}", 26, GREY, ba, fk="I")
            if s > 0: f.text((x, 760 - h * s - 26), f"{round(s * 100)}%", 26, WHITE, prog(t, 20.6 + 0.9 * k, 21.0 + 0.9 * k))
        f.rect(820, 300, 850, 330, mix(BG, WHITE, 0.75 * wa), r=4); f.text((865, 315), "with new kids", 28, WHITE, wa, anchor="lm")
        f.rect(1220, 300, 1250, 330, mix(BG, PURPLE, 0.35 * wa), r=4); f.text((1265, 315), "with her friends", 28, PURPLE, wa, anchor="lm")
    cap(f, "Lena and Jay eat lunch in the same room, at the same table.", win(t, 1.0, 8.2), y=975)
    cap(f, "Jay sees his friends.", win(t, 8.4, 12.4), y=975)
    cap(f, "Lena sees the kid sitting alone. She has been that kid, five times.", win(t, 12.6, 18.8), y=975, col=YELLOW)
    cap(f, "Week after week, more of her lunches go to new kids.", win(t, 19.2, 25.8), y=975)
    cap(f, "What she noticed changed where her time went.", prog(t, 26.0, 26.7), y=975, col=YELLOW)
S_ST3 = (s_st3, 31.5)
S_C3 = partcard("Story 3", "The new kid at lunch", "same room, different eyes")
S_T3 = (tie(3, ["Her past changed what she noticed.", "Then what she noticed changed where her time went."],
            "She sees the kid alone because she has been that kid. She cannot unsee it.",
            ["H6: the past changes how the new is seen", "H1: and attention follows"]), 12.5)

# Story 4
GK = {16: [.80, .10, .10], 22: [.60, .30, .10], 26: [.10, .75, .15], 32: [.06, .62, .32], 38: [.06, .62, .32], 40: [.28, .44, .28]}
GNAMES, GCOLS = ["music", "work", "family"], [BLUE, GOLD, PURPLE]
def gk(age):
    ks = sorted(GK)
    for a_, b_ in zip(ks[:-1], ks[1:]):
        if age <= b_:
            w = (age - a_) / (b_ - a_); return [p + (q - p) * w for p, q in zip(GK[a_], GK[b_])]
    return GK[ks[-1]]
X4 = lambda age: 320 + (age - 16) / 24 * 1440
Y0, Y1 = 290, 770
def band_mid(i, age):
    sh = gk(age); return (X4(age), Y1 - (Y1 - Y0) * (sum(sh[:i]) + sh[i] / 2))
def s_st4(t, f):
    story_header(f, "Story 4: The guitar in the closet")
    person(f, 120, 470, 26, BLUE, prog(t, 0.3, 0.8)); f.text((120, 532), "Omar", 32, BLUE, prog(t, 0.5, 1.0))
    A = 16 + 6 * ease(prog(t, 0.8, 4.6)) + 15.5 * ease(prog(t, 5.2, 11.6)) + 2.5 * ease(prog(t, 22.6, 27.0))
    ages = [a for a in np.linspace(16, 40, 121) if a <= A + 1e-6]
    if len(ages) >= 2:
        for i in range(3):
            lo = [(X4(a), Y1 - (Y1 - Y0) * sum(gk(a)[:i])) for a in ages]; hi = [(X4(a), Y1 - (Y1 - Y0) * sum(gk(a)[:i + 1])) for a in ages]
            f.poly(lo + hi[::-1], fill=mix(BG, GCOLS[i], 0.28))
            f.text((X4(16) - 18, (lo[0][1] + hi[0][1]) / 2), GNAMES[i], 30, GCOLS[i], 1, anchor="rm")
    f.line([(X4(16), Y1 + 20), (X4(16) + (X4(40) - X4(16)) * prog(t, 0.6, 2.0), Y1 + 20)], GREY, 2)
    for age in range(16, 41, 4):
        if A >= age - 0.01: f.text((X4(age), Y1 + 50), ("age " if age == 16 else "") + str(age), 26, GREY, 1, fk="I")
    path = []
    for a in ages:
        if a <= 23: path.append(band_mid(0, a))
        elif a <= 26: w = ease((a - 23) / 3); p0, p1 = band_mid(0, a), band_mid(1, a); path.append((p0[0], p0[1] + (p1[1] - p0[1]) * w))
        elif a <= 38: path.append(band_mid(1, a))
        else: w = ease(min(1, (a - 38) / 0.8)); p0, p1 = band_mid(1, a), band_mid(0, a); path.append((p0[0], p0[1] + (p1[1] - p0[1]) * w))
    f.line(path, WHITE, 4)
    if path and A < 39.9: f.glow(path[-1][0], path[-1][1], 7, WHITE)
    old = band_mid(0, 18)
    if A >= 18: f.glow(old[0], old[1], 26 * back(prog(t, 1.8, 2.4)), BLUE)
    f.text((old[0], old[1] - 60), "his first band", 28, WHITE, prog(t, 2.2, 2.7), fk="I")
    ga = win(t, 7.0, 13.0)
    gx, gy = X4(27), 210
    guitar(f, gx, gy + 20, 40, BLUE, ga * (1 - 0.6 * prog(t, 9.5, 11.0))); f.text((gx + 50, gy + 10), "into the closet", 28, GREY, ga, anchor="lm", fk="I")
    nw = band_mid(1, 38); na = prog(t, 14.6, 15.2)
    if na > 0:
        pl = ease(prog(t, 16.4, 18.4))
        if pl > 0:
            arc = bez((old[0] + 30, old[1]), (old[0] + 400, old[1] - 140), (nw[0] - 300, nw[1] - 240), (nw[0], nw[1] - 20), 40)
            f.line(partial(arc, pl), BLUE, 9)
        Rn = 10 + 26 * ease(prog(t, 18.4, 20.4))
        f.glow(nw[0], nw[1], Rn * back(na), mix(WHITE, YELLOW, prog(t, 18.4, 20.4)))
        f.text((nw[0] - 20, nw[1] + 70), "two minutes: a street musician", 28, WHITE, prog(t, 15.0, 15.6), anchor="rm", fk="I")
    cap(f, "At 18, music is most of Omar's life.", win(t, 1.0, 5.0), y=975)
    cap(f, "By 26, work has taken over. The guitar goes into a closet.", win(t, 5.2, 12.0), y=975)
    cap(f, "Twelve years pass.", win(t, 12.0, 14.4), y=975)
    cap(f, "At 38, a street musician plays for two minutes.", win(t, 14.6, 18.2), y=975)
    cap(f, "The song lands on twenty years of buried meaning.", win(t, 18.4, 22.6), y=975, col=YELLOW)
    cap(f, "That night, he opens the closet.", prog(t, 22.8, 23.5), y=975, col=YELLOW)
S_ST4 = (s_st4, 30.0)
S_C4 = partcard("Story 4", "The guitar in the closet", "a path that comes back")
def s_t4(t, f):
    tie(4, ["A life is one path, and it can come back to an old pursuit.", "A new moment can make an old meaning loud again."],
        "He could not unsee who he had been.", ["H5: one path that comes back", "H6: the past pulls on the new"])(t, f)
S_T4 = (s_t4, 13.0)

def s_data4(t, f):
    story_header(f, "Story 4: and in real data")
    f.text((960, 240), "Do real people come back like Omar?", 52, WHITE, write=ease(prog(t, 0.2, 1.4)))
    f.text((960, 420), "74%", 140, YELLOW, prog(t, 1.6, 2.2), fk="B")
    para(f, (960, 560), "of 247 people in a three-month diary still meant to return to a goal they had set aside.", 40, WHITE, prog(t, 2.2, 2.9), maxw=1400)
    para(f, (960, 720), "But that intention faded over the three months, faster than the goal's value did. Without an Omar moment, the way back fades.", 38, GREY, prog(t, 4.4, 5.1), maxw=1450, fk="I")
S_D4 = (s_data4, 11.0)

# Finale
def icon(f, k, x, y, a):
    if k == 0: bubble(f, x - 60, y - 36, x + 60, y + 24, (x - 40, y + 46), "", a, TEAL)
    elif k == 1: chair(f, x, y + 4, 34, BLUE, 4, a=a)
    elif k == 2:
        f.rect(x - 55, y - 22, x + 55, y + 22, mix(BG, WHITE, 0.06 * a), r=10, outline=mix(BG, GREY, a), w=2)
        f.circle(x, y + 40, 10, fill=mix(BG, WHITE, a)); f.line([(x - 40, y - 40), (x, y + 30)], mix(BG, PURPLE, a), 4)
    else: guitar(f, x, y + 20, 30, GOLD, a)
def s_pattern(t, f):
    f.text((960, 110), "Four stories, one pattern", 58, WHITE, write=ease(prog(t, 0.2, 1.3)))
    items = ["Ten minutes outweighed four years.", "One weekend became a lens.", "A lens moved where the time went.", "A new moment woke an old meaning."]
    for k, s in enumerate(items):
        x = 200 if k % 2 == 0 else 1020; y = 330 if k < 2 else 560; a = prog(t, 1.4 + 1.6 * k, 2.0 + 1.6 * k)
        icon(f, k, x, y, a); f.text((x + 110, y), s, 38, WHITE, a, anchor="lm")
    f.text((960, 760), "Each time, the past did not stay in the past.", 44, WHITE, prog(t, 8.4, 9.1), rise=12)
    f.text((960, 830), "It became part of how they see.", 44, WHITE, prog(t, 9.4, 10.1), rise=12)
    f.text((960, 960), "We see what we cannot unsee.", 64, YELLOW, write=ease(prog(t, 11.0, 12.6)))
S_PATTERN = (s_pattern, 17.0)

def s_words(t, f):
    f.text((960, 100), "The whole idea, in one line", 54, WHITE, write=ease(prog(t, 0.2, 1.3)))
    rows = [(1.4, "how strongly something new grabs you", WHITE), (2.4, "=", GREY), (3.0, "how strongly it would grab anyone", BLUE)]
    for k, (ts, s, col) in enumerate(rows): f.text((960, 240 + 80 * k), s, 46 if s != "=" else 56, col, prog(t, ts, ts + 0.6))
    f.row(960, 490, [("+", 56, GREY, "R"), (r"$\gamma$", 76, YELLOW, "R"), (r"$\times$", 56, GREY, "R")], prog(t, 4.2, 4.8), gap=0.5)
    f.text((960, 580), "your similar past that mattered", 46, GOLD, prog(t, 5.0, 5.6))
    f.row(960, 720, [(r"$\gamma$", 52, YELLOW, "R"), ("is the pull of the past. In all four stories,", 40, WHITE, "R"), (r"$\gamma>0$.", 46, YELLOW, "R")], prog(t, 7.0, 7.7), gap=0.3)
    f.row(960, 820, [("How big is", 40, WHITE, "R"), (r"$\gamma$", 52, YELLOW, "R"), ("in real lives? Nobody has measured it yet.", 40, WHITE, "R")], prog(t, 9.0, 9.7), gap=0.3)
    f.text((960, 940), "Some pieces of the idea have evidence. This core piece is still a hypothesis.", 32, GREY, prog(t, 10.8, 11.5), fk="I")
S_WORDS = (s_words, 16.0)

def s_end(t, f):
    f.text((960, 330), "We see what we cannot unsee.", 88, WHITE, write=ease(prog(t, 0.2, 1.6)))
    f.text((960, 520), "The stories are made up to illustrate the idea. They are not data.", 32, GREY, prog(t, 2.0, 2.6), fk="I")
    f.text((960, 640), "Idea: Roddsi        Stories and animation: Claude", 36, WHITE, prog(t, 3.0, 3.6))
    f.text((960, 760), "For the full argument, the mathematics and the evidence, see the full video.", 30, GREY, prog(t, 4.2, 4.8), fk="I")
S_END = (s_end, 10.0)

SCENES = [S_OPEN, S_C1, S_ST1, S_T1, S_C2, S_ST2, S_T2, S_C3, S_ST3, S_T3, S_C4, S_ST4, S_T4, S_D4, S_PATTERN, S_WORDS, S_END]

def frame(i, t):
    fn, dur = SCENES[i]; f = Frame(); fn(t, f)
    fade = min(1.0, t / 0.4, (dur - t) / 0.4) if i > 0 else min(1.0, (dur - t) / 0.4)
    return f.finish(max(fade, 0.0))

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "list":
        tot = 0
        for i, (fn, d) in enumerate(SCENES): print(i, fn.__name__, d, round(tot, 1)); tot += d
        print("total", tot)
    elif mode == "still":
        for spec in sys.argv[2].split(","):
            i, tt = spec.split(":"); frame(int(i), float(tt)).save(f"{sys.argv[3]}/st{int(i):02d}_{float(tt):05.1f}.png")
    elif mode == "render":
        i = int(sys.argv[2]); outdir = sys.argv[3]; fn, dur = SCENES[i]
        tmp = os.path.join(outdir, f"scene{i:02d}.part.mp4"); final = os.path.join(outdir, f"scene{i:02d}.mp4")
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
               "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-r", str(FPS), tmp]
        pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        for k in range(int(round(dur * FPS))): pr.stdin.write(frame(i, k / FPS).tobytes())
        pr.stdin.close()
        if pr.wait() == 0: os.replace(tmp, final)
        else: sys.exit(1)
