"""Long explainer: opening, Part 1 (idea), Part 2 (math + shape), Part 3 (evidence), closing. Written by Claude.
Usage: python3 long.py still <scene> <t> <out.png> | render <scene> <outdir> | list"""
import sys, os, subprocess
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lv_common import *
from lv_part1 import PART1
from lv_part2 import PART2
from lv_part3 import PART3, CLOSING

SCENES = PART1 + PART2 + PART3 + CLOSING

def frame(i, t):
    fn, dur = SCENES[i]; f = Frame(); fn(t, f)
    fade = min(1.0, t / 0.4, (dur - t) / 0.4) if i > 0 else min(1.0, (dur - t) / 0.4)
    return f.finish(max(fade, 0.0))

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "list":
        tot = 0
        for i, (fn, d) in enumerate(SCENES): print(i, fn.__name__, d, round(tot, 1)); tot += d
        print("total", tot)
    elif mode == "still":
        frame(int(sys.argv[2]), float(sys.argv[3])).save(sys.argv[4])
    elif mode == "render":
        i = int(sys.argv[2]); outdir = sys.argv[3]; fn, dur = SCENES[i]
        tmp = os.path.join(outdir, f"scene{i:02d}.part.mp4"); final = os.path.join(outdir, f"scene{i:02d}.mp4")
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
               "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-r", str(FPS), tmp]
        pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        for k in range(int(round(dur * FPS))):
            pr.stdin.write(frame(i, k / FPS).tobytes())
        pr.stdin.close()
        if pr.wait() == 0: os.replace(tmp, final)
        else: sys.exit(1)
