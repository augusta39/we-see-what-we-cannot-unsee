"""Shared helpers for the long explainer. Written by Claude."""
import sys
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from explainer import *  # noqa: F401,F403  (Frame, sprite, colours, easing, s_* scenes)
import explainer as EX
from PIL import ImageFont

P1H = "Part 1: The idea"
P2H = "Part 2: The mathematics and the shape"
P3H = "Part 3: The evidence"
P4H = "Closing"

_fonts = {}
def tw(s, size, fk="R"):
    key = (size, fk)
    if key not in _fonts: _fonts[key] = ImageFont.truetype(FONTS[fk], size)
    return _fonts[key].getlength(s)

def wrap(s, size, maxw, fk="R"):
    lines, cur = [], ""
    for w in s.split():
        nxt = (cur + " " + w).strip()
        if tw(nxt, size, fk) <= maxw or not cur: cur = nxt
        else: lines.append(cur); cur = w
    if cur: lines.append(cur)
    return lines

def para(f, xy, s, size, col=WHITE, a=1.0, maxw=1650, lh=1.3, anchor="mm", fk="R", write=None, rise=0):
    lines = wrap(s, size, maxw, fk); x, y = xy; n = len(lines)
    y0 = y - (n - 1) * size * lh / 2
    for i, l in enumerate(lines):
        wr = None if write is None else clamp(write * n - i)
        f.text((x, y0 + i * size * lh), l, size, col, a, anchor, fk, wr, rise)
    return n

def header(f, s): f.text((56, 44), s, 26, GREY, anchor="lm", fk="I")
def title(f, t, s, y=110, size=58, t0=0.2): f.text((960, y), s, size, WHITE, write=ease(prog(t, t0, t0 + 1.1)))
def cap(f, s, a, y=980, size=40, col=WHITE, maxw=1700, fk="R"):
    if a > 0: para(f, (960, y), s, size, col, a, maxw=maxw, fk=fk, rise=12)
def win(t, a, b, fade=0.4): return clamp(min(prog(t, a, a + fade), 1 - prog(t, b - fade, b)))

def chip_w(s, size=38): return tw(s, size, "B") + 34
def chip(f, x, y, s, col, a, size=38, anchor="l"):
    w = chip_w(s, size)
    if anchor == "r": x = x - w
    if a > 0:
        f.rect(x, y - size * 0.72, x + w, y + size * 0.72, mix(BG, col, 0.15 * a), r=12, outline=mix(BG, col, a), w=3)
        f.text((x + w / 2, y), s, size, col, a, fk="B")
    return w

def hyp(f, t, lab, s, y, t0, size=40, maxw=1600):
    w = chip_w(lab); chip(f, 90, y, lab, YELLOW, prog(t, t0, t0 + 0.4))
    para(f, (90 + w + 26, y), s, size, WHITE, maxw=maxw - w, anchor="lm", write=ease(prog(t, t0 + 0.2, t0 + 1.8)))

def fmt(v): return f"{v:+.2f}".replace("-", "−")
def fmt2(v): return f"{v:.2f}".replace("-", "−")

def interp_keys(keys, u):
    ks = sorted(keys)
    if u <= ks[0]: return list(keys[ks[0]])
    for a_, b_ in zip(ks[:-1], ks[1:]):
        if u <= b_:
            w = (u - a_) / (b_ - a_); return [p + (q - p) * w for p, q in zip(keys[a_], keys[b_])]
    return list(keys[ks[-1]])

def ring(f, cx, cy, r, col, a, w=3):
    if a > 0 and r > 0.5: f.circle(cx, cy, r, outline=mix(BG, col, clamp(a)), w=w)

def coefplot(f, t, rows, x0, x1, vmin, vmax, y0, dy, t0, step=1.8, ticks=None, lab_w=600):
    X = lambda v: x0 + (v - vmin) / (vmax - vmin) * (x1 - x0)
    a = prog(t, t0, t0 + 0.6); yb = y0 + dy * (len(rows) - 1) + 60
    if a > 0:
        f.dashed((X(0), y0 - 60), (X(0), yb), mix(BG, GREY, a), 2)
        f.line([(x0, yb), (x1, yb)], mix(BG, GREY, a), 2)
        for v in (ticks or []):
            f.line([(X(v), yb), (X(v), yb + 10)], mix(BG, GREY, a), 2)
            f.text((X(v), yb + 34), fmt2(v) if v else "0", 26, GREY, a)
        f.text((X(0), y0 - 84), "no effect", 26, GREY, a, fk="I")
    for k, (lab, b, lo, hi, col) in enumerate(rows):
        ts = t0 + 0.5 + step * k; y = y0 + dy * k
        para(f, (x0 - 34, y), lab, 32, WHITE, prog(t, ts, ts + 0.5), maxw=lab_w, anchor="rm", lh=1.25)
        p = ease(prog(t, ts + 0.3, ts + 1.1))
        if p > 0:
            f.line([(X(b) - (X(b) - X(lo)) * p, y), (X(b) + (X(hi) - X(b)) * p, y)], col, 5)
            for e in (lo, hi):
                xe = X(b) + (X(e) - X(b)) * p; f.line([(xe, y - 12), (xe, y + 12)], col, 4)
            f.glow(X(b), y, 11 * back(prog(t, ts + 0.2, ts + 0.7)), col)
        f.text((x1 + 30, y), f"{fmt(b)}   [{fmt2(lo)}, {fmt2(hi)}]", 32, col, prog(t, ts + 0.9, ts + 1.4), anchor="lm")

# ---------- the upright frustum (x lifespan, y time spent, z tangible) ----------
FW0, FD0, FL, FLAM = 2.4, 1.1, 1.3, 0.55
XC, ZC = FW0 / 2, FD0 / 2
def hw(y): return FW0 / 2 * (1 - FLAM * y / FL)
def hd(y): return FD0 / 2 * (1 - FLAM * y / FL)
def corner(y, sx, sz): return (XC + sx * hw(y), y, ZC + sz * hd(y))

def projector(yaw_deg, pitch_deg, sc, c3, scr):
    yaw, pit = math.radians(yaw_deg), math.radians(pitch_deg)
    def P(x, y, z):
        x, y, z = x - c3[0], y - c3[1], z - c3[2]
        x1 = x * math.cos(yaw) + z * math.sin(yaw); z1 = -x * math.sin(yaw) + z * math.cos(yaw)
        y1 = y * math.cos(pit) + z1 * math.sin(pit)
        return (scr[0] + sc * x1, scr[1] - sc * y1)
    return P

def front_pt(frac, y):
    return (XC - hw(y) + frac * 2 * hw(y), y, ZC - hd(y))

def draw_frustum(f, P, p=1.0, ytop=FL, fill=1.0, front_col=WHITE):
    C = lambda y, sx, sz: P(*corner(y, sx, sz))
    if fill > 0:
        f.poly([C(0, -1, -1), C(ytop, -1, -1), C(ytop, -1, 1), C(0, -1, 1)], fill=mix(BG, WHITE, 0.05 * fill))
        f.poly([C(ytop, -1, -1), C(ytop, 1, -1), C(ytop, 1, 1), C(ytop, -1, 1)], fill=mix(BG, WHITE, 0.04 * fill))
    if p <= 0: return
    hidden = [(C(0, -1, 1), C(0, 1, 1)), (C(0, 1, 1), C(ytop, 1, 1)), (C(0, 1, -1), C(0, 1, 1))]
    seen = [(C(0, -1, -1), C(0, -1, 1)), (C(0, -1, 1), C(ytop, -1, 1)), (C(ytop, -1, 1), C(ytop, -1, -1)),
            (C(ytop, -1, 1), C(ytop, 1, 1)), (C(ytop, 1, 1), C(ytop, 1, -1))]
    front = [(C(0, -1, -1), C(0, 1, -1)), (C(0, 1, -1), C(ytop, 1, -1)), (C(ytop, 1, -1), C(ytop, -1, -1)), (C(ytop, -1, -1), C(0, -1, -1))]
    for grp, col, w in ((hidden, DIM, 2), (seen, GREY, 2), (front, front_col, 3)):
        for a_, b_ in grp: f.line(partial([a_, b_], p), col, w)

FSH2 = {0: [.30, .30, .25, .15], .25: [.45, .20, .20, .15], .5: [.20, .45, .20, .15], .75: [.30, .20, .35, .15], 1: [.25, .30, .20, .25]}
def draw_strips(f, P, fill, yfrac=1.0, keys=FSH2):
    ys = np.linspace(0, FL * yfrac, 40)
    if fill <= 0 or len(ys) < 2 or yfrac <= 0: return
    for i in range(4):
        lo = [P(*front_pt(sum(interp_keys(keys, y / FL)[:i]), y)) for y in ys]
        hi = [P(*front_pt(sum(interp_keys(keys, y / FL)[:i + 1]), y)) for y in ys]
        f.poly(lo + hi[::-1], fill=mix(BG, PCOL[i], 0.30 * fill))
        if i < 3: f.line(hi, mix(BG, PCOL[i], fill), 2)

def strip_mid(i, y, keys=FSH2):
    sh = interp_keys(keys, y / FL); return front_pt(sum(sh[:i]) + sh[i] / 2, y)
