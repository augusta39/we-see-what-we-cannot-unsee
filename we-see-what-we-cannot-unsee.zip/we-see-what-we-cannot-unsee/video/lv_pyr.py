"""Part 2 shape scenes, redrawn for the cumulative reading: x = lifespan, y = time spent so far in each
pursuit (stacked, so the top edge is t), z = the tangible. The solid opens from 'me' as a pyramid. Written by Claude."""
from lv_common import *

PL, PY, PD = 2.6, 1.5, 1.1           # length (x at t = L), stack height at L, depth at L
_U = np.linspace(0, 1, 401)
_A = np.array([interp_keys(FSH2, u) for u in _U])            # attention shares a_i(u)
_TAU = np.vstack([np.zeros(4), np.cumsum((_A[1:] + _A[:-1]) / 2 * np.diff(_U)[:, None], axis=0)])  # tau_i(u), sums to u
def tau(u): return np.array([np.interp(u, _U, _TAU[:, i]) for i in range(4)])
def band_y(i, u, frac=0.5):
    tt = tau(u); return PY * (tt[:i].sum() + frac * tt[i])
def front(i, u, frac=0.5): return (PL * u, band_y(i, u, frac), 0.0)
B0, B1, B2, B3 = (PL, 0, 0), (PL, PY, 0), (PL, PY, PD), (PL, 0, PD)
O3 = (0, 0, 0)

def pyrP(t, dur, yaw0=18, dyaw=6, pitch=32, sc=290, scr=(900, 540)):
    return projector(yaw0 + dyaw * ease(t / dur), pitch, sc, (PL / 2, PY / 2, PD / 2), scr)

def draw_bands(f, P, umax=1.0, a=1.0):
    us = [u for u in np.linspace(0, 1, 81) if u <= umax + 1e-9]
    if a <= 0 or len(us) < 2: return
    for i in range(4):
        lo = [P(PL * u, band_y(i, u, 0), 0) for u in us]; hi = [P(PL * u, band_y(i, u, 1), 0) for u in us]
        f.poly(lo + hi[::-1], fill=mix(BG, PCOL[i], 0.32 * a))
        if i < 3: f.line(hi, mix(BG, PCOL[i], a), 2)

def draw_pyr(f, P, p=1.0, faces=1.0, ext=0.0):
    if faces > 0:
        f.poly([P(*O3), P(*B1), P(*B2)], fill=mix(BG, WHITE, 0.04 * faces))
        f.poly([P(*B0), P(*B1), P(*B2), P(*B3)], fill=mix(BG, WHITE, 0.06 * faces))
    if p <= 0: return
    hidden = [(O3, B3)]
    seen = [(O3, B2), (B1, B2), (B2, B3), (B3, B0)]
    front_e = [(O3, B0), (B0, B1), (O3, B1)]
    for grp, col, w in ((hidden, DIM, 2), (seen, GREY, 2), (front_e, WHITE, 3)):
        for a_, b_ in grp: f.line(partial([P(*a_), P(*b_)], p), col, w)
    if ext > 0:
        for c in (B0, B1, B2, B3):
            far = tuple(v * (1 + 0.22 * ext) for v in c)
            f.dashed(P(*c), P(*far), GREY, 2, 10, 8)

def pyr_axes(f, P, pa=(1, 1, 1), labels=(1, 1, 1), size=32, col=WHITE):
    o = P(*O3); out = []
    for k, (tip, lab, anc, off) in enumerate((((PL + 0.55, 0, 0), "x   lifespan", "lm", (14, 0)),
                                               ((0, PY + 0.45, 0), "y   time spent so far", "rm", (-16, 0)),
                                               ((0, 0, PD + 0.6), "z   tangible", "lm", (14, -8)))):
        p = ease(pa[k]); b = P(tip[0] * p, tip[1] * p, tip[2] * p)
        if p > 0: f.arrow(o, b, GREY, 3, 14 if p > 0.3 else 0)
        f.text((b[0] + off[0], b[1] + off[1]), lab, size, col, labels[k], anchor=anc)
        out.append(b)
    return out

def s_axes3d(t, f):
    header(f, P2H); title(f, t, "7.  The shape of a life: your sketch, in three dimensions", size=50)
    P = pyrP(t, 22.5)
    pyr_axes(f, P, (prog(t, 1.6, 3.0), prog(t, 3.4, 4.8), prog(t, 15.0, 16.4)), (prog(t, 2.6, 3.1), prog(t, 4.4, 4.9), prog(t, 16.0, 16.5)))
    o = P(*O3)
    f.text((o[0], o[1] + 34), "t = 0", 26, GREY, prog(t, 2.6, 3.1), fk="I")
    e = P(PL, 0, 0); f.text((e[0], e[1] + 34), "L", 28, GREY, prog(t, 2.6, 3.1), fk="I")
    U = ease(prog(t, 7.8, 13.0))
    draw_bands(f, P, U, prog(t, 7.8, 8.2))
    if 0 < U < 1:
        a_, b_ = P(PL * U, 0, 0), P(PL * U, PY * U, 0); f.line([a_, b_], WHITE, 2)
        f.text((a_[0], a_[1] + 32), "age t", 26, WHITE, 1, fk="I")
    if U > 0.98:
        for i in range(4):
            q = P(*front(i, 1.0)); f.p((q[0] + 16, q[1]), r"$P_%d$" % (i + 1), 30, PCOL[i], prog(t, 13.0, 13.5), anchor="lm")
    da = prog(t, 12.0, 12.8) * (1 - prog(t, 15.4, 16.0))
    if da > 0:
        f.dashed(P(*O3), P(*B1), mix(BG, YELLOW, da), 4, 14, 8)
        m = P(PL * 0.45, PY * 0.45, 0); f.text((m[0] - 20, m[1] - 34), "together: your age", 30, YELLOW, da, anchor="rm", fk="I")
    if t > 15.4: draw_pyr(f, P, ease(prog(t, 15.6, 17.4)), faces=prog(t, 15.6, 17.4))
    f.star(o[0], o[1], 20 * back(prog(t, 0.8, 1.3)), YELLOW); f.text((o[0] - 36, o[1] - 30), "me", 32, YELLOW, prog(t, 1.0, 1.5), fk="I")
    caps = [(1.0, 2.6, "Start with you, at the origin."),
            (2.6, 7.6, "x: your lifespan, from t = 0 to the end of a life, L."),
            (7.6, 11.8, "y: the total time spent so far in each pursuit, P1 to P4, stacked one on another."),
            (12.0, 15.0, "Together the bands always add up to your age, so their top edge is a straight diagonal."),
            (15.0, 19.0, "z: the tangible. Matter, in space and time: physical, temporal, as the brain registers it.")]
    for a_, b_, s in caps: cap(f, s, win(t, a_, b_), y=980, size=36)
    cap(f, "Notice what none of the three axes measures: what an experience meant.", prog(t, 19.2, 19.9), y=980, size=40, col=YELLOW)
S_AXES3D = (s_axes3d, 22.5)

def s_pyramid(t, f):
    header(f, P2H); title(f, t, "8.  Why the shape is a pyramid", size=52)
    P = pyrP(t, 22.0, yaw0=18, dyaw=5, sc=235, scr=(610, 560))
    pyr_axes(f, P, labels=(1, 1, 1), size=26, col=GREY)
    ext = ease(prog(t, 10.2, 12.2)) * (1 - prog(t, 14.6, 15.4))
    draw_bands(f, P, 1.0, 1.0); draw_pyr(f, P, 1.0, faces=1.0, ext=ext)
    o = P(*O3); f.star(o[0], o[1], 18, YELLOW); f.text((o[0] - 32, o[1] - 28), "me", 28, YELLOW, 1, fk="I")
    da = prog(t, 1.2, 2.0) * (1 - prog(t, 5.2, 5.8))
    if da > 0: f.line([P(*O3), P(*B1)], mix(BG, YELLOW, da), 6)
    su = 0.15 + 0.85 * ease(prog(t, 5.6, 9.0)); sa = prog(t, 5.4, 5.9) * (1 - prog(t, 9.6, 10.2))
    if sa > 0:
        q = [P(PL * su, 0, 0), P(PL * su, PY * su, 0), P(PL * su, PY * su, PD * su), P(PL * su, 0, PD * su)]
        f.poly(q, fill=mix(BG, YELLOW, 0.18 * sa), outline=mix(BG, YELLOW, sa), w=3)
    ap = prog(t, 8.6, 9.2) * (1 - prog(t, 10.0, 10.6))
    if ap > 0: ring(f, o[0], o[1], 34, YELLOW, ap, 3)
    ba = prog(t, 12.6, 13.4)
    if ba > 0:
        q = [P(*B0), P(*B1), P(*B2), P(*B3)]; f.poly(q, fill=mix(BG, YELLOW, 0.2 * ba), outline=mix(BG, YELLOW, ba), w=3)
        c = P(*B0); f.p((c[0] + 10, c[1] + 40), r"$x=L$", 32, YELLOW, ba)
    rx = 1500
    f.tex((rx, 300), r"$\sum_i \tau_i(t)=t$", 56, YELLOW, write=ease(prog(t, 1.2, 2.4)))
    f.p((rx, 375), "all the time spent, in every pursuit, adds up to the time lived,", 28, GREY, prog(t, 2.4, 3.0))
    f.p((rx, 412), "so the top edge rises exactly with age", 28, GREY, prog(t, 2.7, 3.3))
    f.p((rx, 520), r"slice at age $t$:   $t \times F(t)$", 44, WHITE, prog(t, 5.6, 6.3))
    f.p((rx, 585), "time spent so far, times what has been made so far", 28, GREY, prog(t, 6.3, 6.9))
    f.p((rx, 622), "at t = 0 both are zero: the apex is you", 28, GREY, prog(t, 8.6, 9.2))
    f.p((rx, 740), "no end of life: it opens forever, an infinite pyramid", 30, WHITE, prog(t, 10.6, 11.3))
    f.p((rx, 785), r"a life ends at $x=L$, which closes it", 30, YELLOW, prog(t, 12.8, 13.5))
    caps = [(1.0, 5.4, "The top edge is no choice: the hours always add up to the time lived."),
            (5.4, 10.2, "Slice the shape at any age: time spent so far, by what has been made so far. Both start at zero, at you."),
            (10.2, 15.0, "If life had no end, the shape would keep opening. A finite life closes it with an end face.")]
    for a_, b_, s in caps: cap(f, s, win(t, a_, b_), y=980, size=36)
    cap(f, "The y side is exact. The z side is a drawing choice: tangible output need not grow steadily, so that face can bend.",
        prog(t, 15.4, 16.1), y=975, size=34, col=YELLOW)
S_PYRAMID = (s_pyramid, 22.0)

PEXPS = [(0.22, 1, 0.75, 0.15, 3.2), (0.4, 0, 0.25, 0.85, 5.0), (0.58, 1, 0.55, 0.30, 6.8), (0.76, 2, 0.35, 0.55, 8.6), (0.92, 1, 0.65, 0.20, 10.4)]
def s_inside(t, f):
    header(f, P2H); title(f, t, "9.  Tangible on the axes, intangible in the dots", size=52)
    P = pyrP(t, 24.0, yaw0=22, dyaw=-6, sc=300, scr=(900, 545))
    pyr_axes(f, P, size=30, col=GREY)
    draw_bands(f, P, 1.0, 1.0); draw_pyr(f, P, 1.0, faces=1.0)
    o = P(*O3); f.star(o[0], o[1], 18, YELLOW); f.text((o[0] - 32, o[1] - 28), "me", 30, YELLOW, 1, fk="I")
    for i in range(4):
        q = P(*front(i, 1.0)); f.p((q[0] + 14, q[1]), r"$P_%d$" % (i + 1), 28, PCOL[i], 1, anchor="lm")
    stops = [(0.07, 1)] + [(u, i) for u, i, *_ in PEXPS] + [(1.0, 3)]
    pts = []
    for (ua, ia), (ub, ib) in zip(stops[:-1], stops[1:]):
        us = np.linspace(ua, ub, 26); w = np.array([ease(x) for x in np.linspace(0, 1, 26)])
        for u_, w_ in zip(us, w):
            ya, yb = band_y(ia, u_), band_y(ib, u_); pts.append(P(PL * u_, ya + (yb - ya) * w_, 0))
    pp = ease(prog(t, 2.0, 12.0)); f.line(partial(pts, pp), WHITE, 4)
    if 0 < pp < 1: q = partial(pts, pp)[-1]; f.glow(q[0], q[1], 7, WHITE)
    grow = ease(prog(t, 19.0, 20.5))
    for k, (u, i, s, F, ts) in enumerate(PEXPS):
        if t < ts: continue
        c3 = front(i, u); q = P(*c3)
        sa = ease(prog(t, 13.6, 14.8))
        if sa > 0:
            qb = P(c3[0], c3[1], F * PD * u * sa * 1.6)
            f.line([q, qb], mix(BG, GREY, 0.9), 3); f.rect(qb[0] - 5, qb[1] - 5, qb[0] + 5, qb[1] + 5, GREY)
        if 0 <= t - ts < 1.4:
            u2 = (t - ts) / 1.4; ring(f, q[0], q[1], 14 + 46 * u2, RED, 1 - u2, 4)
        R = (6 + 17 * s + (12 if k == 1 else 0) * grow) * back(prog(t, ts + 0.3, ts + 0.8))
        f.glow(q[0], q[1], R, YELLOW)
    q1 = P(*front(1, PEXPS[0][0])); f.text((q1[0] - 40, q1[1] - 60), "red flash: the feeling, gone in days", 28, RED, win(t, 3.4, 7.6), anchor="rm", fk="I")
    vt = ease(prog(t, 17.2, 18.2))
    if vt > 0:
        v = P(PL, PY * 0.55, PD * 0.5); f.star(v[0], v[1], 16 * back(vt), WHITE)
        for (u, i, s, F, ts) in PEXPS:
            q = P(*front(i, u)); f.dashed(v, (v[0] + (q[0] - v[0]) * vt, v[1] + (q[1] - v[1]) * vt), mix(BG, WHITE, 0.45), 2)
    caps = [(0.8, 6.2, "Each band is one pursuit. It thickens whenever you give it time."),
            (6.4, 11.6, "The path is one life: it moves between pursuits, and comes back."),
            (11.8, 13.4, "Each dot is an experience. Its size is its significance, on no axis."),
            (13.6, 17.0, "Each stick shows what it tangibly produced. A long stick can hold a small dot, and the reverse."),
            (17.2, 24.0, "From the end of a life, looking back: the same experiences, seen anew. One grows in meaning years later.")]
    for a_, b_, s in caps: cap(f, s, win(t, a_, b_), y=980, size=36, col=YELLOW if a_ in (11.8, 17.2) else WHITE)
S_INSIDE = (s_inside, 24.0)

def s_map(t, f):
    header(f, P2H); title(f, t, "10.  A map, not the territory", size=54)
    pcs = [(r"$\Gamma(t)=($", 60, WHITE, "R"), (r"$t$", 60, WHITE, "R"), (",", 60, GREY, "R"), (r"$\tau(t)$", 60, TEAL, "R"), (",", 60, GREY, "R"),
           (r"$F(t)$", 60, GOLD, "R"), (",", 60, GREY, "R"), (r"$S(t)$", 60, YELLOW, "R"), (",", 60, GREY, "R"), (r"$a(t)$", 60, PURPLE, "R"), (r"$)$", 60, WHITE, "R")]
    pos = f.row(960, 300, pcs, write=ease(prog(t, 0.8, 2.4)), gap=0.3)
    labs = [(r"$t$", "lifespan: the x axis", WHITE), (r"$\tau(t)$", "time spent so far in each pursuit: the y axis, stacked", TEAL),
            (r"$F(t)$", "what has been made, the tangible: the z axis", GOLD), (r"$S(t)$", "significance: the size of the dots, on no axis", YELLOW),
            (r"$a(t)$", "attention shares: how fast each band thickens", PURPLE)]
    for k, (sym, s, col) in enumerate(labs):
        ts = 2.8 + 0.8 * k; a = prog(t, ts, ts + 0.5); y = 430 + 58 * k
        f.p((640, y), sym, 40, col, a, anchor="rm"); f.text((680, y), s, 32, col, a, anchor="lm")
    f.p((960, 760), r"$\frac{d\tau_i}{dt}=a_i(t)$:  a band's slope is the share of attention it is getting now", 34, WHITE, prog(t, 7.0, 7.7))
    cap(f, "Five coordinates, three drawable axes. Any drawing of a life is a projection.", prog(t, 8.6, 9.3), y=860, size=38)
    cap(f, "The shape is a map, not the territory.", prog(t, 10.0, 10.7), y=945, size=46, col=YELLOW)
S_MAP = (s_map, 14.0)
