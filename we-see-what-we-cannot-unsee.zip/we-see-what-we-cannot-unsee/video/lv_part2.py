"""Part 2: the mathematics and the shape. Written by Claude."""
from lv_common import *
from lv_part1 import partcard

S_P2 = partcard("Part 2", "The mathematics and the shape", "every symbol, one at a time")

def s_budget(t, f):
    header(f, P2H); title(f, t, "1.  Time is a budget")
    cx0, cx1, cy0, cy1 = 200, 1020, 330, 800
    axes(f, (cx0, cy1), cx1 + 40, cy0 - 30, ease(prog(t, 0.8, 1.6)))
    f.text((cx1 + 56, cy1), "time", 30, GREY, prog(t, 1.4, 1.9), anchor="lm", fk="I")
    f.text((cx0 + 14, cy0 - 40), "shares", 30, GREY, prog(t, 1.4, 1.9), anchor="lm", fk="I")
    fill = ease(prog(t, 1.6, 3.0)); T = ease(prog(t, 7.2, 10.4))
    us = np.linspace(0, 1, 61)
    for i in range(4):
        sub = [u for u in us if u <= fill + 1e-9]
        if len(sub) < 2: break
        lo = [(cx0 + (cx1 - cx0) * u, cy1 - (cy1 - cy0) * sum(interp_keys(FSH2, u)[:i])) for u in sub]
        hi = [(cx0 + (cx1 - cx0) * u, cy1 - (cy1 - cy0) * sum(interp_keys(FSH2, u)[:i + 1])) for u in sub]
        f.poly(lo + hi[::-1], fill=mix(BG, PCOL[i], 0.22))
        if i == 1 and T > 0:
            m = [k for k, u in enumerate(sub) if u <= T + 1e-9]
            if len(m) >= 2: f.poly([lo[k] for k in m] + [hi[k] for k in m][::-1], fill=mix(BG, PCOL[i], 0.75))
        f.text((cx0 + 40, (lo[0][1] + hi[0][1]) / 2), PNAMES[i], 28, PCOL[i], fill, anchor="lm")
    if T > 0:
        xt = cx0 + (cx1 - cx0) * T; f.line([(xt, cy0), (xt, cy1)], WHITE, 2); f.text((xt, cy1 + 30), "t", 30, WHITE, fk="I")
    rx = 1460
    f.tex((rx, 330), r"$a_i(t)\geq 0,\qquad \sum_i a_i(t)=1$", 52, WHITE, write=ease(prog(t, 2.8, 4.0)))
    f.p((rx, 405), r"$a_i(t)$: the share of attention pursuit $i$ gets at time $t$", 30, GREY, prog(t, 4.0, 4.6))
    f.p((rx, 445), "the shares always add up to 1", 30, GREY, prog(t, 4.3, 4.9))
    f.tex((rx, 570), r"$\tau_i(t)=\int_0^t a_i(s)\,ds$", 56, TEAL, write=ease(prog(t, 6.0, 7.2)))
    f.p((rx, 650), r"$\tau_i(t)$: total time given to pursuit $i$ so far", 30, GREY, prog(t, 7.2, 7.8))
    f.p((rx, 690), "= the area of its band, up to time t", 30, GREY, prog(t, 7.6, 8.2))
    f.tex((rx, 800), r"$\sum_i \tau_i(t)=t$", 56, YELLOW, write=ease(prog(t, 11.0, 12.0)))
    f.p((rx, 870), "add every band's area: you get the time lived", 30, GREY, prog(t, 12.0, 12.6))
    cap(f, "Every hour given to one pursuit is an hour taken from another.", prog(t, 13.6, 14.3), y=985, col=YELLOW)
S_BUDGET = (s_budget, 18.5)

def s_clocks2(t, f):
    header(f, P2H); title(f, t, "2.  Two clocks: feeling and meaning")
    lx = 500
    f.tex((lx, 255), r"$\frac{dE}{dt}=-\lambda E+\alpha\,x(t)$", 54, RED, write=ease(prog(t, 1.0, 2.2)))
    f.p((lx, 330), r"feeling $E$ jumps with the experience $x(t)$,", 30, GREY, prog(t, 2.2, 2.8))
    f.p((lx, 368), r"then fades at a fast rate $\lambda$", 30, GREY, prog(t, 2.5, 3.1))
    f.tex((lx, 470), r"$\frac{dC}{dt}=-\mu\,(C-b)+\beta E$", 54, BLUE, write=ease(prog(t, 5.4, 6.6)))
    f.p((lx, 545), r"meaning $C$ is fed by feeling (strength $\beta$),", 30, GREY, prog(t, 6.6, 7.2))
    f.p((lx, 583), r"and drifts back to its baseline $b$ at a slow rate $\mu$", 30, GREY, prog(t, 6.9, 7.5))
    o = (1000, 620); xe, yt = 1820, 250
    axes(f, o, xe, yt, ease(prog(t, 1.8, 2.6)))
    f.text((xe, 655), "days", 28, GREY, prog(t, 2.4, 2.9), anchor="rm", fk="I")
    lam, mu = 0.35, 0.04; tst = math.log(lam / mu) / (lam - mu); cm = (math.exp(-mu * tst) - math.exp(-lam * tst)) / (lam - mu)
    X = lambda d: o[0] + d / 60 * (1780 - o[0]); Y = lambda v: o[1] - v * (o[1] - 290)
    days = np.linspace(0, 60, 400)
    fe = [(X(d), Y(math.exp(-lam * d))) for d in days]
    ce = [(X(d), Y((math.exp(-mu * d) - math.exp(-lam * d)) / (lam - mu) / cm)) for d in days]
    f.line(partial(fe, ease(prog(t, 3.0, 4.6))), RED, 5); f.line(partial(ce, ease(prog(t, 7.4, 10.0))), BLUE, 6)
    f.text((X(3.5), Y(0.75)), "E", 34, RED, prog(t, 4.2, 4.6), fk="I")
    f.text((X(30), Y(0.62) - 30), "C", 34, BLUE, prog(t, 9.0, 9.4), fk="I")
    sp = ease(prog(t, 15.4, 16.4))
    if sp > 0:
        f.dashed((X(tst), o[1]), (X(tst), o[1] - (o[1] - 290) * sp), YELLOW, 3)
        f.text((X(tst), o[1] + 30), "t*", 30, YELLOW, sp, fk="I")
    f.tex((700, 725), r"$C(t)-b=\frac{\beta\alpha U}{\lambda-\mu}\left(e^{-\mu t}-e^{-\lambda t}\right)$", 52, BLUE, write=ease(prog(t, 11.0, 12.6)))
    f.p((1180, 725), r"for one brief experience of total size $U$", 30, GREY, prog(t, 12.6, 13.2), anchor="lm")
    f.tex((640, 880), r"$t^{*}=\frac{\ln(\lambda/\mu)}{\lambda-\mu}>0$", 54, YELLOW, write=ease(prog(t, 14.2, 15.4)))
    f.p((1000, 880), "meaning peaks after the feeling has faded", 32, WHITE, prog(t, 15.6, 16.2), anchor="lm")
    cap(f, "This shows delayed meaning is possible, not that it is common.", prog(t, 18.2, 18.9), y=1010, size=32, col=GREY, fk="I")
S_CLOCKS2 = (s_clocks2, 23.0)

def _sim(U, d, alpha, lam=0.25, mu=0.03, T=40, dt=0.02, start=1.0):
    n = int(T / dt) + 1; E = C = 0.0; out = []
    for k in range(n):
        tt = k * dt; x = U / d if start <= tt < start + d else 0.0
        E += dt * (-lam * E + alpha * x); C += dt * (-mu * C + E); out.append(C)
    return np.array(out)
_DA = [_sim(1, 3, 1.0), _sim(1, 3, 0.4)]; _DB = [_sim(1, 0.25, 1.0), _sim(1, 1.5, 1.0)]
_DMAX = max(c.max() for c in _DA + _DB)
def s_dur(t, f):
    header(f, P2H); title(f, t, "3.  How long it lasted does not fix how much it matters", size=52)
    f.tex((960, 235), r"$C\;\neq\;k\cdot d$", 58, YELLOW, write=ease(prog(t, 1.0, 2.0)))
    f.p((960, 300), r"no law says: meaning $=$ a constant $\times$ the duration $d$", 32, GREY, prog(t, 2.0, 2.6))
    panels = [(150, 880, "same duration, different strength", _DA, [GOLD, TEAL], [(1, 3), (1, 3)], "different meaning", 3.0),
              (1040, 1770, "different duration, same total", _DB, [BLUE, PURPLE], [(1, 0.25), (1, 1.5)], "nearly the same meaning", 8.0)]
    for x0, x1, lab, curves, cols, spans, res, ts in panels:
        o = (x0, 780); axes(f, o, x1, 420, ease(prog(t, ts, ts + 0.8)))
        f.text(((x0 + x1) / 2, 385), lab, 34, WHITE, prog(t, ts + 0.2, ts + 0.7))
        X = lambda d: x0 + d / 40 * (x1 - 40 - x0); Y = lambda v: 780 - v / _DMAX * 320
        for k, (c, col, (st, dd)) in enumerate(zip(curves, cols, spans)):
            p = ease(prog(t, ts + 0.8 + 0.9 * k, ts + 2.4 + 0.9 * k))
            pts = [(X(i * 0.02), Y(v)) for i, v in enumerate(c)][::10]
            f.line(partial(pts, p), col, 5)
            yb = 800 + 18 * k; a = prog(t, ts + 0.6 + 0.9 * k, ts + 1.0 + 0.9 * k)
            if a > 0: f.rect(X(st), yb, max(X(st + dd), X(st) + 4), yb + 12, mix(BG, col, a), r=3)
        f.text((x0 + 120, 862), "experience lasted:", 24, GREY, prog(t, ts + 0.6, ts + 1.0), anchor="rm", fk="I")
        f.text(((x0 + x1) / 2, 910), "→  " + res, 36, cols[0], prog(t, ts + 3.4, ts + 4.0))
    f.text((330, 560), "stronger", 28, GOLD, prog(t, 5.0, 5.4), anchor="lm", fk="I")
    f.text((330, 700), "weaker", 28, TEAL, prog(t, 5.8, 6.2), anchor="lm", fk="I")
    cap(f, "Duration can matter. It is just not a law.", prog(t, 13.2, 13.9), y=990, col=YELLOW)
S_DUR = (s_dur, 17.5)

def _soft(S, th=2.0):
    e = np.exp(th * np.array(S)); return e / e.sum()
def s_soft(t, f):
    header(f, P2H); title(f, t, "4.  Attention follows significance, but only relatively", size=52)
    f.tex((520, 270), r"$a_i=\frac{e^{\theta S_i+h_i}}{\sum_k e^{\theta S_k+h_k}}$", 64, WHITE, write=ease(prog(t, 0.8, 2.2)))
    f.p((960, 215), r"$S_i$: how significant pursuit $i$ feels", 32, GREY, prog(t, 2.3, 2.8), anchor="lm")
    f.p((960, 265), r"$h_i$: obligations and access", 32, GREY, prog(t, 2.8, 3.3), anchor="lm")
    f.p((960, 315), r"$\theta$: how strongly attention follows significance", 32, GREY, prog(t, 3.3, 3.8), anchor="lm")
    S0 = np.array([1.0, 0.6, 0.3]); S = S0 + 0.5 * ease(prog(t, 8.2, 10.0)) + np.array([0, 0, 0.8]) * ease(prog(t, 13.0, 14.8))
    A = _soft(S); a = ease(prog(t, 4.2, 5.2)); base = 840
    for k in range(3):
        xs = 360 + 160 * k; xa = 1220 + 160 * k; col = PCOL[k]
        hS = 190 * S[k] * a; hA = 560 * A[k] * a
        if hS > 1: f.rect(xs - 55, base - hS, xs + 55, base, mix(BG, col, 0.35), r=6, outline=col, w=2)
        if hA > 1: f.rect(xa - 55, base - hA, xa + 55, base, mix(BG, col, 0.7), r=6)
        f.text((xs, base + 30), PNAMES[k], 28, col, a); f.text((xa, base + 30), PNAMES[k], 28, col, a)
        f.text((xa, base - hA - 26), f"{A[k]:.2f}", 28, col, a)
    f.text((520, 920), "significance  S", 32, GREY, a, fk="I"); f.text((1380, 920), "attention share  a", 32, GREY, a, fk="I")
    pa = ease(prog(t, 5.0, 6.0))
    if pa > 0: f.arrow((800, 640), (800 + 320 * pa, 640), WHITE, 4, 18); f.text((960, 605), "softmax", 30, WHITE, pa, fk="I")
    cap(f, "Raise every significance by the same amount: attention does not move.", win(t, 8.4, 12.6), y=995, size=36, col=YELLOW)
    cap(f, "Raise one above the rest: attention shifts toward it.", win(t, 13.2, 17.4), y=995, size=36, col=YELLOW)
    if t > 17.4:
        aa = prog(t, 17.6, 18.3)
        f.tex((820, 995), r"$\delta a_i\approx\theta\,a_i\left(\delta S_i-\sum_k a_k\,\delta S_k\right)$", 42, WHITE, aa)
        f.p((1160, 995), "only relative change moves attention", 32, YELLOW, aa, anchor="lm")
S_SOFT = (s_soft, 22.0)

def s_gap(t, f):
    header(f, P2H); title(f, t, "5.  What matters and where the time goes can drift apart", size=50)
    f.tex((960, 240), r"$G=\frac{1}{2}\sum_i\;\left|\,p_i-a_i\,\right|\;=\;1-\sum_i\;\min(p_i,a_i)$", 52, WHITE, write=ease(prog(t, 0.9, 2.3)))
    f.p((960, 330), r"$p_i$: share of significance          $a_i$: share of attention", 32, GREY, prog(t, 2.3, 2.9))
    p = np.array([.15, .45, .15, .25]); a0 = np.array([.50, .15, .20, .15]); a1 = np.array([.20, .40, .15, .25])
    A = a0 + (a1 - a0) * ease(prog(t, 7.6, 11.0)); G = 0.5 * np.abs(p - A).sum()
    al = ease(prog(t, 3.0, 4.0)); base = 860; sc = 800
    for i in range(4):
        x = 360 + 270 * i; col = PCOL[i]
        hp, ha = p[i] * sc * al, A[i] * sc * al
        if ha > 1: f.rect(x + 6, base - ha, x + 86, base, mix(BG, col, 0.75), r=5)
        if hp > 1: f.rect(x - 86, base - hp, x - 6, base, None, r=5, outline=col, w=3)
        lo, hi = sorted([hp, ha])
        if hi - lo > 3:
            f.line([(x - 92, base - hi), (x + 92, base - hi)], RED, 2); f.line([(x - 92, base - lo), (x + 92, base - lo)], RED, 2)
            f.line([(x + 104, base - hi), (x + 104, base - lo)], RED, 5)
        f.text((x, base + 32), PNAMES[i], 30, col, al)
    lx = 1500
    f.rect(lx, 455, lx + 40, 485, None, r=4, outline=WHITE, w=3); f.text((lx + 60, 470), "what matters  (p)", 30, WHITE, al, anchor="lm")
    f.rect(lx, 515, lx + 40, 545, mix(BG, WHITE, 0.7), r=4); f.text((lx + 60, 530), "where time goes  (a)", 30, WHITE, al, anchor="lm")
    f.line([(lx + 20, 572), (lx + 20, 608)], RED, 5); f.text((lx + 60, 590), "the mismatch", 30, RED, al, anchor="lm")
    f.tex((lx + 150, 720), r"$G=%.2f$" % G, 60, YELLOW, al)
    cap(f, "Here friends matter most, but study takes the time: G is large.", win(t, 4.2, 7.6), y=990, size=36)
    cap(f, "G = 0: your time matches what matters.   G = 1: no overlap at all.", prog(t, 11.4, 12.1), y=990, size=36, col=YELLOW)
S_GAP = (s_gap, 16.0)

def s_pulleq(t, f):
    header(f, P2H)
    f.row(960, 100, [("6.  The central term: the pull of the past", 52, WHITE, "R")], write=ease(prog(t, 0.2, 1.3)))
    eq = f.row(960, 255, [(r"$\alpha_k$", 62, WHITE, "R"), (r"$=$", 62, GREY, "R"), (r"$\alpha_0$", 62, BLUE, "R"), (r"$+$", 62, GREY, "R"),
                          (r"$\gamma$", 62, YELLOW, "R"), (r"$\sum_{j<k}$", 62, GREY, "R"), (r"$\mathrm{sim}(j,k)$", 62, PURPLE, "R"),
                          (r"$C_j(s_k)$", 62, GOLD, "R")], write=ease(prog(t, 1.2, 2.8)), gap=0.34)
    rows = [(3.2, r"$\alpha_k$", WHITE, "how strongly a new experience k registers"),
            (4.4, r"$\alpha_0$", BLUE, "how strongly it would register for anyone"),
            (5.6, r"$\mathrm{sim}(j,k)$", PURPLE, "how similar an earlier experience j is to k"),
            (6.8, r"$C_j(s_k)$", GOLD, "how much j still matters at the moment k begins"),
            (8.0, r"$\gamma$", YELLOW, "the dial: how much the past pulls")]
    for k, (ts, sym, col, s) in enumerate(rows):
        y = 420 + 78 * k
        f.p((690, y), sym, 44, col, prog(t, ts, ts + 0.5), anchor="rm")
        f.p((740, y), s, 38, col, anchor="lm", write=ease(prog(t, ts + 0.1, ts + 1.1)))
    hl = ease(prog(t, 9.0, 9.6))
    if hl > 0: ring(f, eq[4][0], 250, 33 * back(hl), YELLOW, 1)
    cases = [(430, r"$\gamma=0$:  no pull (the null)", GREY), (960, r"$\gamma>0$:  carryover", YELLOW), (1490, r"$\gamma<0$:  habituation", BLUE)]
    for k, (x, s, col) in enumerate(cases):
        f.p((x, 850), s, 40, col, prog(t, 10.2 + 0.8 * k, 10.7 + 0.8 * k))
    a = prog(t, 13.4, 14.1)
    f.p((960, 960), r"This is the same $\alpha$ that sets the size of the feeling in the two-clock model:", 34, GREY, a)
    f.p((960, 1005), r"a bigger $\alpha_k$ means a bigger feeling, and so a bigger meaning.", 34, GREY, a)
S_PULLEQ = (s_pulleq, 19.0)

def s_dial2(t, f):
    header(f, P2H); EX.s_dial(t, f)
S_DIAL2 = (s_dial2, 13.0)

# ---------- geometry ----------
GEO = dict(sc=290, c3=(XC, FL / 2, ZC), scr=(900, 560))
def geoP(t, dur, yaw0=-32, dyaw=10, pitch=20, **kw):
    g = dict(GEO); g.update(kw); return projector(yaw0 + dyaw * ease(t / dur), pitch, g["sc"], g["c3"], g["scr"])

def s_axes3d(t, f):
    header(f, P2H); title(f, t, "7.  The shape of a life: your sketch, in three dimensions", size=50)
    P = geoP(t, 21.0)
    o = P(0, 0, 0)
    def axis(tip, t0, t1):
        p = ease(prog(t, t0, t1)); b = P(tip[0] * p, tip[1] * p, tip[2] * p)
        if p > 0: f.arrow(o, b, GREY, 3, 14 if p > 0.3 else 0)
        return P(*tip)
    bx = axis((FW0 + 0.5, 0, 0), 1.6, 3.0); by = axis((0, FL + 0.45, 0), 7.6, 9.0); bz = axis((0, 0, FD0 + 0.7), 12.6, 14.0)
    f.text((bx[0] + 14, bx[1]), "x   lifespan", 32, WHITE, prog(t, 2.6, 3.1), anchor="lm")
    f.text((by[0] - 16, by[1]), "y   time spent", 32, WHITE, prog(t, 8.6, 9.1), anchor="rm")
    f.text((bz[0] - 14, bz[1] - 10), "z   tangible", 32, WHITE, prog(t, 13.6, 14.1), anchor="rm")
    f.text((o[0], o[1] + 30), "t = 0", 26, GREY, prog(t, 2.6, 3.1), fk="I")
    e = P(FW0, 0, 0); f.text((e[0], e[1] + 30), "L", 28, GREY, prog(t, 2.6, 3.1), fk="I")
    sa = ease(prog(t, 3.6, 4.8)); sh = [.30, .30, .25, .15]
    sh2 = [.18, .42, .20, .20]; w = ease(prog(t, 5.6, 7.0)); sh = [p + (q - p) * w for p, q in zip(sh, sh2)] if t < 7.6 else [p + (q - p) * (1 - ease(prog(t, 7.6, 8.6))) for p, q in zip(sh, sh2)]
    if sa > 0 and t < 9.6:
        x = 0
        for i, s in enumerate(sh):
            a_, b_ = P(x * FW0, 0, 0), P((x + s) * FW0, 0, 0)
            f.line([a_, b_], mix(BG, PCOL[i], sa * (1 - prog(t, 9.0, 9.6))), 10)
            m = P((x + s / 2) * FW0, 0, 0); f.p((m[0], m[1] + 44), r"$P_%d$" % (i + 1), 32, PCOL[i], sa * (1 - prog(t, 9.0, 9.6)))
            x += s
    yf = ease(prog(t, 9.4, 12.4))
    draw_strips(f, P, prog(t, 9.4, 9.8), yfrac=yf)
    if yf > 0:
        ytop = FL * yf; C = lambda y, sx: P(*corner(y, sx, -1))
        f.line([C(0, -1), C(0, 1), C(ytop, 1), C(ytop, -1), C(0, -1)], WHITE, 3)
    if t > 14.0: draw_frustum(f, P, ease(prog(t, 14.0, 15.6)), fill=prog(t, 14.0, 15.6))
    f.star(o[0], o[1], 20 * back(prog(t, 0.8, 1.3)), YELLOW); f.text((o[0] - 34, o[1] - 34), "me", 32, YELLOW, prog(t, 1.0, 1.5), fk="I")
    caps = [(1.0, 2.6, "Start with you, at the origin."),
            (2.6, 7.8, "x: your lifespan, from t = 0 to L, shared among pursuits P1, P2, P3, P4, whose widths move with your priorities."),
            (7.8, 12.8, "y: the time spent on those pursuits, rising layer by layer. Each layer has its own mix."),
            (12.8, 17.4, "z: the tangible. Matter, in space and time: physical, temporal, as the brain registers it.")]
    for a_, b_, s in caps: cap(f, s, win(t, a_, b_), y=975, size=36)
    cap(f, "Notice what none of the three axes measures: what an experience meant.", prog(t, 17.6, 18.3), y=975, size=40, col=YELLOW)
S_AXES3D = (s_axes3d, 21.5)

def s_frustum(t, f):
    header(f, P2H); title(f, t, "8.  Why a frustum, and not a pyramid", size=52)
    apex = FL / FLAM
    P = projector(-30 + 8 * ease(t / 21), 18, 215, (XC, apex / 2, ZC), (600, 590))
    full = 1 - ease(prog(t, 4.2, 5.4))
    C = lambda y, sx, sz: P(*corner(y, sx, sz)); A = P(XC, apex, ZC)
    pa = ease(prog(t, 1.0, 3.2))
    for sx, sz in ((-1, -1), (1, -1), (-1, 1), (1, 1)):
        top = C(FL, sx, sz)
        if pa > 0:
            seg = partial([top, A], pa)
            if full > 0.02: f.line(seg, mix(BG, WHITE, 0.6 * full), 2)
            if full < 0.98: f.dashed(seg[0], seg[-1], mix(BG, GREY, 1 - full), 2, 10, 8)
    draw_frustum(f, P, 1.0, fill=1.0)
    f.glow(A[0], A[1], 6 * pa, WHITE)
    cut = ease(prog(t, 4.0, 5.2))
    if cut > 0:
        q = [C(FL, -1, -1), C(FL, 1, -1), C(FL, 1, 1), C(FL, -1, 1)]
        f.poly(q, fill=mix(BG, YELLOW, 0.22 * cut), outline=mix(BG, YELLOW, cut), w=3)
    tr = C(FL, 1, -1); f.p((tr[0] + 20, tr[1] + 6), r"$y=L$", 32, YELLOW, prog(t, 5.0, 5.5), anchor="lm")
    f.p((A[0] + 20, A[1]), r"$y=L/\lambda$", 32, GREY, prog(t, 14.2, 14.7), anchor="lm")
    ym = FL * 0.45; wa = ease(prog(t, 8.2, 9.2))
    if wa > 0:
        l_, r_ = C(ym, -1, -1), C(ym, 1, -1); mx_ = ((l_[0] + r_[0]) / 2, (l_[1] + r_[1]) / 2)
        f.arrow(mx_, (mx_[0] + (r_[0] - mx_[0]) * wa, mx_[1] + (r_[1] - mx_[1]) * wa), YELLOW, 3, 12)
        f.arrow(mx_, (mx_[0] + (l_[0] - mx_[0]) * wa, mx_[1] + (l_[1] - mx_[1]) * wa), YELLOW, 3, 12)
        f.p((mx_[0], mx_[1] - 26), r"$W(y)$", 30, YELLOW, wa)
    rx = 1460
    f.tex((rx, 330), r"$W(y)=W_0\left(1-\lambda\,\frac{y}{L}\right)$", 52, WHITE, write=ease(prog(t, 7.0, 8.2)))
    f.p((rx, 410), r"the width once time $y$ has been spent,   $0<\lambda<1$", 30, GREY, prog(t, 8.2, 8.8))
    f.tex((rx, 540), r"$W(L)=W_0\,(1-\lambda)>0$", 52, YELLOW, write=ease(prog(t, 10.4, 11.6)))
    f.p((rx, 615), "at the end of a life the width is still above zero:", 30, GREY, prog(t, 11.6, 12.2))
    f.p((rx, 655), "the pursuits stay distinct, never one point", 30, GREY, prog(t, 11.9, 12.5))
    f.p((rx, 770), r"the sides meet only at $y=L/\lambda>L$", 38, WHITE, prog(t, 13.8, 14.5))
    f.p((rx, 825), "beyond any life", 30, GREY, prog(t, 14.4, 15.0))
    caps = [(1.0, 4.0, "Extend the sides upward and they meet at a point: a pyramid."),
            (4.2, 7.0, "But a life ends at L. Cut it there, and a frustum is what is left.")]
    for a_, b_, s in caps: cap(f, s, win(t, a_, b_), y=985, size=38)
    if t > 16.6:
        f.p((960, 985), r"$\lambda$ is a drawing choice.  $\lambda=0$ is just as valid: nothing forces a life to narrow.", 38, YELLOW, prog(t, 16.8, 17.5))
S_FRUSTUM = (s_frustum, 21.0)

EXPS = [(0.18, 1, 0.75, 0.15, 3.2), (0.36, 0, 0.25, 0.85, 5.0), (0.55, 1, 0.55, 0.30, 6.8), (0.74, 2, 0.35, 0.55, 8.6), (0.9, 1, 0.65, 0.20, 10.4)]
def s_inside(t, f):
    header(f, P2H); title(f, t, "9.  Tangible on the axes, intangible in the dots", size=52)
    P = geoP(t, 24.0, yaw0=-26, dyaw=-8, sc=320, scr=(930, 555))
    o = P(0, 0, 0)
    for tip, lab, anc, off in (((FW0 + 0.5, 0, 0), "x  lifespan", "lm", (14, 0)), ((0, FL + 0.45, 0), "y  time spent", "rm", (-16, 0)), ((0, 0, FD0 + 0.7), "z  tangible", "rm", (-14, -10))):
        b = P(*tip); f.arrow(o, b, GREY, 3, 14); f.text((b[0] + off[0], b[1] + off[1]), lab, 30, GREY, 1, anchor=anc, fk="I")
    draw_frustum(f, P, 1.0, fill=1.0); draw_strips(f, P, 1.0)
    f.star(o[0], o[1], 18, YELLOW); f.text((o[0] - 32, o[1] - 32), "me", 30, YELLOW, 1, fk="I")
    for i in range(4):
        m = P(*front_pt(sum(FSH2[0][:i]) + FSH2[0][i] / 2, 0)); f.p((m[0], m[1] + 38), r"$P_%d$" % (i + 1), 30, PCOL[i], 1)
    path3 = [strip_mid(1, 0.0)] + [strip_mid(i, u * FL) for u, i, *_ in EXPS] + [strip_mid(2, FL)]
    pts = []
    for a_, b_ in zip(path3[:-1], path3[1:]):
        ym = (a_[1] + b_[1]) / 2; pts += bez(a_, (a_[0], ym, a_[2]), (b_[0], ym, b_[2]), b_, 24)
    pp = ease(prog(t, 2.0, 12.0)); pts2 = [P(*q) for q in pts]; f.line(partial(pts2, pp), WHITE, 4)
    grow = ease(prog(t, 19.0, 20.5))
    for k, (u, i, s, F, ts) in enumerate(EXPS):
        if t < ts: continue
        c3 = strip_mid(i, u * FL); q = P(*c3)
        sa = ease(prog(t, 13.6, 14.8))
        if sa > 0:
            back3 = (c3[0], c3[1], c3[2] + F * 2 * hd(c3[1]) * sa); qb = P(*back3)
            f.line([q, qb], mix(BG, GREY, 0.9), 3); f.rect(qb[0] - 5, qb[1] - 5, qb[0] + 5, qb[1] + 5, GREY)
        if 0 <= t - ts < 1.4:
            u2 = (t - ts) / 1.4; ring(f, q[0], q[1], 14 + 46 * u2, RED, 1 - u2, 4)
        R = (6 + 17 * s + (12 if k == 1 else 0) * grow) * back(prog(t, ts + 0.3, ts + 0.8))
        f.glow(q[0], q[1], R, YELLOW)
    q1 = P(*strip_mid(1, EXPS[0][0] * FL)); f.text((q1[0] + 60, q1[1] + 10), "red flash: the feeling, gone in days", 28, RED, win(t, 3.4, 7.6), anchor="lm", fk="I")
    vt = ease(prog(t, 17.2, 18.2))
    if vt > 0:
        v = P(XC, FL, ZC); f.star(v[0], v[1], 16 * back(vt), WHITE)
        for (u, i, s, F, ts) in EXPS:
            q = P(*strip_mid(i, u * FL)); f.dashed(v, (v[0] + (q[0] - v[0]) * vt, v[1] + (q[1] - v[1]) * vt), mix(BG, WHITE, 0.45), 2)
    caps = [(0.8, 6.2, "The strips are pursuits. Their widths move as priorities move."),
            (6.4, 11.6, "The path is one life: it hops between pursuits, and comes back."),
            (11.8, 13.4, "Each dot is an experience. Its size is its significance, on no axis."),
            (13.6, 17.0, "Each stick shows what it tangibly produced. A long stick can hold a small dot, and the reverse."),
            (17.2, 24.0, "From the top face, looking back: the same experiences, seen anew. One grows in meaning years later.")]
    for a_, b_, s in caps: cap(f, s, win(t, a_, b_), y=980, size=36, col=YELLOW if a_ in (11.8, 17.2) else WHITE)
S_INSIDE = (s_inside, 24.0)

def s_map(t, f):
    header(f, P2H); title(f, t, "10.  A map, not the territory", size=54)
    pcs = [(r"$\Gamma(t)=($", 60, WHITE, "R"), (r"$t$", 60, WHITE, "R"), (",", 60, GREY, "R"), (r"$\tau(t)$", 60, TEAL, "R"), (",", 60, GREY, "R"),
           (r"$F(t)$", 60, GOLD, "R"), (",", 60, GREY, "R"), (r"$S(t)$", 60, YELLOW, "R"), (",", 60, GREY, "R"), (r"$a(t)$", 60, PURPLE, "R"), (r"$)$", 60, WHITE, "R")]
    pos = f.row(960, 300, pcs, write=ease(prog(t, 0.8, 2.4)), gap=0.3)
    labs = [(1, "lifespan: x", WHITE, 0), (3, "time spent: y", TEAL, 1), (5, "tangible: z", GOLD, 0), (7, "significance: dot size", YELLOW, 1), (9, "attention: strip widths", PURPLE, 0)]
    for k, (idx, s, col, lvl) in enumerate(labs):
        ts = 2.8 + 0.8 * k; a = prog(t, ts, ts + 0.5); x = pos[idx][0]; y = 450 + 80 * lvl
        if a > 0: f.line([(x, 345), (x, y - 26)], mix(BG, col, a), 2)
        f.text((x, y), s, 32, col, a)
    cap(f, "Five coordinates, three drawable axes. Any drawing of a life is a projection.", prog(t, 7.4, 8.1), y=720, size=42)
    cap(f, "The shape is a map, not the territory.", prog(t, 9.0, 9.7), y=820, size=48, col=YELLOW)
S_MAP = (s_map, 13.5)

from lv_pyr import S_AXES3D as P_AXES, S_PYRAMID, S_INSIDE as P_INSIDE, S_MAP as P_MAP
PART2 = [S_P2, S_BUDGET, S_CLOCKS2, S_DUR, S_SOFT, S_GAP, S_PULLEQ, S_DIAL2, P_AXES, S_PYRAMID, P_INSIDE, P_MAP]
