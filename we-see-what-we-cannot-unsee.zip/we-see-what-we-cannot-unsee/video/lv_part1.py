"""Opening and Part 1 (the idea). Written by Claude."""
from lv_common import *

def s_open(t, f):
    f.text((960, 420), "We see what we cannot unsee", 100, WHITE, write=ease(prog(t, 0.3, 1.9)))
    f.text((960, 535), "Pursuits and Perception", 46, GREY, prog(t, 1.6, 2.3), fk="I")
    f.text((960, 600), "an idea, its mathematics, and the evidence so far", 34, GREY, prog(t, 2.2, 2.9), fk="I")
    pts = wiggle(400, 1520, 800, 38); p = ease(prog(t, 2.0, 5.5)); f.line(partial(pts, p), BLUE, 5)
    for u, r, c in [(0.14, 10, GOLD), (0.37, 22, TEAL), (0.6, 8, PURPLE), (0.84, 16, YELLOW)]:
        if p >= u:
            q = pts[int(u * (len(pts) - 1))]; f.glow(q[0], q[1], r * back(prog(t, 2.0 + 3.5 * u, 2.4 + 3.5 * u)), c)
S_OPEN = (s_open, 7.0)

def s_hook(t, f):
    f.text((960, 110), "Two experiences", 60, WHITE, write=ease(prog(t, 0.2, 1.2)))
    f.text((900, 250), "how long it lasted", 34, GREY, prog(t, 1.0, 1.5), fk="I")
    f.text((1560, 250), "how much it mattered", 34, GREY, prog(t, 3.6, 4.1), fk="I")
    rows = [(400, "a ten-minute conversation", 0.0, TEAL, 58, "redirected a career", "10 minutes"),
            (640, "a four-year degree", 1.0, GOLD, 12, "a line on a résumé", "4 years")]
    for k, (y, lab, frac, col, R, res, dlab) in enumerate(rows):
        ts = 1.2 + 0.5 * k
        f.text((520, y), lab, 40, WHITE, prog(t, ts, ts + 0.5), anchor="rm")
        L = ease(prog(t, ts + 0.4, ts + 1.8)) * max(frac * 700, 8)
        if L > 0: f.rect(560, y - 22, 560 + L, y + 22, mix(BG, GREY, 0.6), r=6)
        f.text((560 + L + 18, y), dlab, 30, GREY, prog(t, ts + 1.6, ts + 2.0), anchor="lm", fk="I")
        f.glow(1560, y, R * back(prog(t, 3.8 + 0.6 * k, 4.4 + 0.6 * k)), col)
        f.text((1560, y + R + 34), res, 34, col, prog(t, 4.2 + 0.6 * k, 4.7 + 0.6 * k), fk="I")
    cap(f, "If meaning followed time spent, neither would be possible.", prog(t, 6.5, 7.2), y=880, size=44)
    cap(f, "Yet both are ordinary.", prog(t, 7.6, 8.3), y=955, size=44, col=YELLOW)
S_HOOK = (s_hook, 12.0)

def partcard(num, name, sub):
    def fn(t, f):
        f.text((960, 400), num, 40, GREY, prog(t, 0.2, 0.7), fk="I")
        f.text((960, 500), name, 92, WHITE, write=ease(prog(t, 0.5, 1.7)))
        w = ease(prog(t, 1.2, 2.2)); f.line([(960 - 420 * w, 590), (960 + 420 * w, 590)], YELLOW, 3)
        f.text((960, 655), sub, 38, GREY, prog(t, 1.8, 2.5), fk="I")
    return (fn, 5.5)
S_P1 = partcard("Part 1", "The idea", "assumptions, six hypotheses, and what is known")

def s_assume(t, f):
    header(f, P1H); title(f, t, "Four starting assumptions")
    rows = [(1.4, "Life is finite.", "Every hour given to one thing is an hour taken from another."),
            (4.6, "We pursue several things at once.", "Work, friends, a craft, family, questions we cannot leave alone."),
            (7.8, "Every experience has two sides.", "Tangible: hours, matter, results.    Intangible: how it felt, and what it came to mean."),
            (11.0, "One person lives one path.", "However many pursuits, it is a single life moving through them.")]
    for k, (ts, a_, b_) in enumerate(rows):
        y = 280 + 155 * k; r = 30 * back(prog(t, ts, ts + 0.5))
        f.circle(250, y + 22, r, outline=BLUE, w=4); f.text((250, y + 22), str(k + 1), 36, BLUE, prog(t, ts + 0.2, ts + 0.6), fk="B")
        f.text((320, y), a_, 46, WHITE, anchor="lm", write=ease(prog(t, ts + 0.2, ts + 1.0)))
        f.text((320, y + 54), b_, 34, GREY, prog(t, ts + 0.9, ts + 1.5), anchor="lm", fk="I")
    cap(f, "From these come six hypotheses.", prog(t, 14.5, 15.2), col=YELLOW)
S_ASSUME = (s_assume, 19.0)

H1KEYS = [(0.0, "year 1", [.45, .25, .10, .20]), (5.5, "year 6", [.30, .35, .20, .15]), (8.0, "year 12", [.20, .25, .40, .15]), (10.5, "year 20", [.35, .15, .15, .35])]
def s_h1(t, f):
    header(f, P1H)
    hyp(f, t, "H1", "A finite life holds several pursuits at once, and their priority changes over time.", 135, 0.2)
    cur = H1KEYS[0][2]; lab = H1KEYS[0][1]
    for tk, l, v in H1KEYS[1:]:
        u = ease(prog(t, tk - 1.1, tk)); cur = [p + (q - p) * u for p, q in zip(cur, v)]
        if t >= tk - 0.55: lab = l
    a = ease(prog(t, 1.6, 2.6)); x0, x1, y0, y1 = 300, 1620, 370, 500
    f.text((960, 275), lab, 36, YELLOW, prog(t, 2.4, 2.9), fk="I")
    if a > 0:
        x = x0
        for i, s in enumerate(cur):
            w = (x1 - x0) * s; xa, xb = x + 4, x + w - 4
            if xb > xa: f.rect(xa, y0, xb, y1, mix(BG, PCOL[i], 0.22 * a), r=10, outline=mix(BG, PCOL[i], a), w=3)
            if w > 110: f.text(((xa + xb) / 2, (y0 + y1) / 2), PNAMES[i], 36, PCOL[i], a)
            f.text(((xa + xb) / 2, y0 - 28), f"{round(s * 100)}%", 30, PCOL[i], a)
            x += w
    f.tex((960, 630), r"$a_{\rm study}+a_{\rm friends}+a_{\rm hobby}+a_{\rm family}=1$", 54, WHITE, write=ease(prog(t, 2.8, 4.0)))
    f.text((960, 712), "Each share is how much of your time one pursuit gets. The shares always add up to 1.", 32, GREY, prog(t, 4.0, 4.6), fk="I")
    f.text((960, 880), "“My experience is what I agree to attend to.”", 44, WHITE, prog(t, 11.2, 11.9), fk="I", rise=12)
    f.text((960, 945), "William James, 1890", 30, GREY, prog(t, 11.6, 12.2))
S_H1 = (s_h1, 15.5)

def s_h2(t, f):
    header(f, P1H)
    hyp(f, t, "H2", "How long an experience lasted, and what it tangibly produced, do not determine how significant it becomes.", 135, 0.2)
    o = (340, 840); xe, yt = 1620, 320
    axes(f, o, xe, yt, ease(prog(t, 1.6, 2.6)))
    f.text((xe, 885), "how long it lasted, or what it produced", 34, GREY, prog(t, 2.4, 2.9), anchor="rm", fk="I")
    f.text((360, 290), "how much it mattered later", 34, GREY, prog(t, 2.4, 2.9), anchor="lm", fk="I")
    rng = np.random.default_rng(3)
    for k, (x, y) in enumerate(zip(rng.uniform(470, 1500, 9), rng.uniform(420, 780, 9))):
        f.circle(x, y, 7 * back(prog(t, 2.8 + 0.08 * k, 3.2 + 0.08 * k)), fill=DIM)
    gp = ease(prog(t, 3.4, 4.4))
    if gp > 0: f.dashed(o, (o[0] + (1560 - o[0]) * gp, o[1] - (o[1] - 360) * gp), GREY, 3)
    f.text((1560, 330), "if duration decided meaning", 30, GREY, prog(t, 4.2, 4.7), anchor="rm", fk="I")
    f.glow(1450, 780, 14 * back(prog(t, 5.0, 5.5)), GOLD)
    f.text((1450, 730), "a long class you forgot", 34, GOLD, prog(t, 5.2, 5.7))
    f.glow(430, 410, 20 * back(prog(t, 6.2, 6.7)), TEAL)
    f.text((470, 410), "10 minutes with a teacher who believed in you", 34, TEAL, prog(t, 6.4, 6.9), anchor="lm")
    f.text((960, 960), "Clock time divides into equal hours. Lived time does not.   (after Henri Bergson, 1889)", 34, GREY, prog(t, 8.8, 9.5), fk="I", rise=12)
S_H2 = (s_h2, 14.0)

def s_h34(t, f):
    header(f, P1H)
    hyp(f, t, "H4", "How an experience feels at the time is distinct from how significant it becomes.", 125, 0.2)
    hyp(f, t, "H3", "Significance can persist, fade, grow, or be reinterpreted after the experience ends.", 200, 1.2)
    o = (260, 830); xe, yt = 1640, 320
    axes(f, o, xe, yt, ease(prog(t, 2.4, 3.2)))
    f.text((xe, 875), "days after it happens", 32, GREY, prog(t, 3.0, 3.5), anchor="rm", fk="I")
    X = lambda d: o[0] + d / 90 * (1580 - o[0]); Y = lambda v: o[1] - v * (o[1] - 370)
    lam, mu = 0.5, 0.02; ts_ = math.log(lam / mu) / (lam - mu); cm = (math.exp(-mu * ts_) - math.exp(-lam * ts_)) / (lam - mu)
    def C(d):
        v = (math.exp(-mu * d) - math.exp(-lam * d)) / (lam - mu) / cm
        if d > 55: v += 0.42 * (1 - math.exp(-(d - 55) / 2.5)) * math.exp(-0.012 * (d - 55))
        return v
    days = np.linspace(0, 90, 600)
    fe = [(X(d), Y(math.exp(-lam * d))) for d in days]; ce = [(X(d), Y(C(d))) for d in days]
    pf = ease(prog(t, 3.4, 5.0)); f.line(partial(fe, pf), RED, 6)
    f.text((X(5), Y(0.42)), "feeling: fast", 36, RED, prog(t, 4.6, 5.1), anchor="lm")
    upto = ease(prog(t, 5.4, 8.4)) * 55 / 90 + ease(prog(t, 10.2, 12.0)) * 35 / 90
    f.line(partial(ce, upto / 1.0) if upto < 1 else ce, BLUE, 7)
    if 0 < upto < 1: q = partial(ce, upto)[-1]; f.glow(q[0], q[1], 8, BLUE)
    f.text((X(14), Y(1.0) - 8), "meaning: slower, and it lingers", 36, BLUE, prog(t, 7.0, 7.5), anchor="lm")
    ev = ease(prog(t, 8.8, 9.8))
    if ev > 0:
        f.dashed((X(55), o[1]), (X(55), o[1] - (o[1] - 400) * ev), YELLOW, 3)
    f.text((X(55) + 14, 400), "a later event changes what it meant", 32, YELLOW, prog(t, 9.4, 9.9), anchor="lm", fk="I")
    f.text((960, 960), "Life is lived forwards, but understood backwards.   (after Søren Kierkegaard, 1843)", 34, GREY, prog(t, 12.6, 13.3), fk="I", rise=12)
S_H34 = (s_h34, 17.0)

def s_h5(t, f):
    header(f, P1H)
    hyp(f, t, "H5", "A life is one continuous, nonlinear path through shifting priorities: not a ladder, not a set of separate tracks.", 135, 0.2)
    x0, x1, y0, y1 = 300, 1640, 330, 790; Hh = y1 - y0
    us = np.linspace(0, 1, 70); fill = ease(prog(t, 1.8, 2.8))
    if fill > 0:
        for i in range(4):
            lo = [(x0 + (x1 - x0) * u, y1 - Hh * sum(interp_keys(FSH2, u)[:i])) for u in us]
            hi = [(x0 + (x1 - x0) * u, y1 - Hh * sum(interp_keys(FSH2, u)[:i + 1])) for u in us]
            f.poly(lo + hi[::-1], fill=mix(BG, PCOL[i], 0.26 * fill))
            f.text((x0 - 20, (lo[0][1] + hi[0][1]) / 2), PNAMES[i], 30, PCOL[i], fill, anchor="rm")
    f.arrow((x0, y1 + 30), (x1, y1 + 30), GREY, 3, 14); f.text((x1, y1 + 65), "your life, over time", 30, GREY, prog(t, 2.2, 2.7), anchor="rm", fk="I")
    visits = [(0.0, 1), (0.14, 0), (0.30, 1), (0.45, 2), (0.6, 1), (0.74, 3), (0.88, 2), (1.0, 1)]
    def mid(u, i): sh = interp_keys(FSH2, u); return (x0 + (x1 - x0) * u, y1 - Hh * (sum(sh[:i]) + sh[i] / 2))
    pts = []
    for (ua, ia), (ub, ib) in zip(visits[:-1], visits[1:]):
        a_, b_ = mid(ua, ia), mid(ub, ib); xm = (a_[0] + b_[0]) / 2; pts += bez(a_, (xm, a_[1]), (xm, b_[1]), b_, 30)
    pp = ease(prog(t, 3.0, 8.5)); f.line(partial(pts, pp), WHITE, 5)
    if 0 < pp < 1: q = partial(pts, pp)[-1]; f.glow(q[0], q[1], 9, WHITE)
    for uu, ts_ in ((0.30, 4.8), (0.6, 6.6)):
        q = mid(uu, 1); a_ = prog(t, ts_, ts_ + 0.5)
        if a_ > 0:
            ring(f, q[0], q[1], 18, WHITE, a_, 3); f.dashed((q[0], y0 - 8), (q[0], q[1] - 22), mix(BG, WHITE, 0.6 * a_), 2, 8, 6)
        f.text((q[0], y0 - 30), "comes back", 30, WHITE, a_, fk="I")
    cap(f, "Nothing forces the path to narrow toward the end, or to end in a single calling.", prog(t, 9.4, 10.1), size=38)
S_H5 = (s_h5, 13.5)

def s_h6(t, f):
    header(f, P1H)
    hyp(f, t, "H6", "Earlier experiences change how later experiences are perceived, interpreted and weighted, and so change which pursuits receive attention.", 135, 0.2)
    cx, cy, rx, ry = 960, 560, 440, 200
    E = lambda th: (cx + rx * math.cos(math.radians(th)), cy + ry * math.sin(math.radians(th)))
    nodes = [(-90, "1.  an experience happens", GOLD), (0, "2.  it gains significance, slowly", BLUE),
             (90, "3.  it becomes a lens for the next similar one", YELLOW), (180, "4.  attention shifts between pursuits", TEAL)]
    for k, (th, lab, col) in enumerate(nodes):
        ts = 2.2 + 1.1 * k; q = E(th)
        f.text(q, lab, 32, col, prog(t, ts, ts + 0.5))
        a0, a1 = th + 24, th + 90 - 22
        arc = [E(a) for a in np.linspace(a0, a1, 30)]; p = ease(prog(t, ts + 0.5, ts + 1.2))
        if p > 0:
            seg = partial(arc, p); f.line(seg, GREY, 3)
            if p > 0.95: f.arrow(arc[-6], arc[-1], WHITE, 3, 26)
    if t > 6.8:
        th = -90 + ((t - 6.8) / 5.0 * 360); q = E(th); f.glow(q[0], q[1], 9, WHITE)
    f.text((cx, cy), "the loop", 34, GREY, prog(t, 6.6, 7.1), fk="I")
    cap(f, "Once you have been betrayed, a friend's small lie reads differently.", win(t, 7.4, 10.8), size=40)
    cap(f, "Once you have built a chair yourself, you cannot look at one the way you did before.", win(t, 11.0, 14.4), size=40)
    cap(f, "Understanding starts from a horizon of earlier judgments.   (after Hans-Georg Gadamer, 1960)", prog(t, 14.6, 15.2), size=36, col=GREY, fk="I")
S_H6 = (s_h6, 19.0)

def s_known(t, f):
    header(f, P1H); title(f, t, "What is already known, and what is not", y=100, size=54)
    a = prog(t, 1.0, 1.6)
    f.line([(960, 190), (960, 810)], mix(BG, DIM, a), 2)
    f.text((520, 205), "Already known", 40, GREEN, a, fk="B"); f.text((1410, 205), "Not yet known", 40, YELLOW, a, fk="B")
    known = [("Past experience colors how new events are read.", "philosophy (James, Gadamer) and a long line of psychology"),
             ("Some memories become central to who we are.", "Berntsen & Rubin, 2006"),
             ("People revise what life events mean, for years.", "Peters et al., 2023"),
             ("Several goals compete for limited attention.", "Neal et al., 2017")]
    unknown = ["Do changes in how much past experiences matter predict how new ones are read?",
               "Do those changes move where our hours go, beyond goals, mood and habits?",
               "Does how long something lasted predict how much it comes to matter?",
               "How strong is the pull of the past?"]
    for k, (s, c) in enumerate(known):
        ts = 2.0 + 1.5 * k; y = 290 + 135 * k; aa = prog(t, ts, ts + 0.5)
        f.circle(150, y, 7, fill=mix(BG, GREEN, aa)) if aa > 0 else None
        n = len(wrap(s, 32, 740)); yy = y - (n - 1) * 20
        para(f, (180, yy), s, 32, WHITE, aa, maxw=740, anchor="lm", lh=1.25)
        f.text((180, yy + (n - 1) * 40 + 44), c, 26, GREY, prog(t, ts + 0.3, ts + 0.8), anchor="lm", fk="I")
    for k, s in enumerate(unknown):
        ts = 8.6 + 1.5 * k; y = 300 + 135 * k; aa = prog(t, ts, ts + 0.5)
        f.circle(1040, y, 7, fill=mix(BG, YELLOW, aa)) if aa > 0 else None
        para(f, (1070, y), s, 32, WHITE, aa, maxw=740, anchor="lm", lh=1.25)
    cap(f, "The new part is narrow: changes in how much past experiences matter should predict how later events are read, and where attention goes, beyond goals, mood and habits.",
        prog(t, 15.4, 16.2), y=935, size=36, col=YELLOW, maxw=1650)
S_KNOWN = (s_known, 23.0)

def s_fail(t, f):
    header(f, P1H); title(f, t, "How this claim could fail")
    rows = ["The past shapes how things are read, but not where the hours go.",
            "It adds nothing beyond the goals, mood and habits we already measure."]
    for k, s in enumerate(rows):
        ts = 1.4 + 2.2 * k; y = 360 + 170 * k; r = 32 * back(prog(t, ts, ts + 0.5))
        f.circle(250, y, r, outline=RED, w=4)
        if r > 20:
            pp = ease(prog(t, ts + 0.3, ts + 0.7)); d = 12
            f.line(partial([(250 - d, y - d), (250 + d, y + d)], pp), RED, 5); f.line(partial([(250 + d, y - d), (250 - d, y + d)], pp), RED, 5)
        para(f, (320, y), s, 42, WHITE, maxw=1450, anchor="lm", write=ease(prog(t, ts + 0.2, ts + 1.4)))
    cap(f, "A claim that can fail is a claim that can be tested.", prog(t, 6.8, 7.5), y=760, size=48, col=YELLOW)
    cap(f, "Next: making every piece of it precise.", prog(t, 8.8, 9.5), y=860, size=36, col=GREY, fk="I")
S_FAIL = (s_fail, 12.5)

PART1 = [S_OPEN, S_HOOK, S_P1, S_ASSUME, S_H1, S_H2, S_H34, S_H5, S_H6, S_KNOWN, S_FAIL]
