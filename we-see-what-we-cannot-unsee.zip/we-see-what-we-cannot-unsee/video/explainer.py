"""'We see what we cannot unsee': explainer in a 3Blue1Brown-like visual style. Written by Claude.
Usage:
  python3 -I explainer.py still <scene> <t> <out.png>
  python3 -I explainer.py render <scene> <outdir>
"""
import sys, os, io, math, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager

W, H, S, FPS = 1920, 1080, 2, 30
BG = (12, 12, 16); WHITE = (236, 236, 236); GREY = (128, 130, 140); DIM = (60, 62, 70)
BLUE = (88, 196, 221); TEAL = (92, 208, 179); GREEN = (131, 193, 103); YELLOW = (247, 213, 96)
GOLD = (240, 172, 95); RED = (252, 98, 85); PURPLE = (154, 114, 172); PINK = (226, 112, 177)
PCOL = [GOLD, TEAL, BLUE, PURPLE]
PNAMES = ["study", "friends", "hobby", "family"]
LM = os.environ.get("LM_FONT_DIR", "/usr/share/texmf/fonts/opentype/public/lm/")
FONTS = {"R": LM + "lmroman10-regular.otf", "B": LM + "lmroman10-bold.otf", "I": LM + "lmroman10-italic.otf"}
font_manager.fontManager.addfont(FONTS["R"]); font_manager.fontManager.addfont(FONTS["I"])
_lm = font_manager.FontProperties(fname=FONTS["R"]).get_name()
plt.rcParams.update({"mathtext.fontset": "cm", "font.family": "serif", "font.serif": [_lm]})

def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def prog(t, a, b): return clamp((t - a) / (b - a)) if b > a else float(t >= a)
def ease(x): x = clamp(x); return x * x * (3 - 2 * x)
def eout(x): x = clamp(x); return 1 - (1 - x) ** 3
def back(x):
    x = clamp(x); c = 1.5; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2
def mix(a, b, u): return tuple(int(round(a[i] + (b[i] - a[i]) * clamp(u))) for i in range(3))

_sp = {}
def sprite(kind, s, size, col, fk="R"):
    key = (kind, s, size, col, fk)
    if key in _sp: return _sp[key]
    if kind == "t":
        f = ImageFont.truetype(FONTS[fk], size); l, tp, r, b = f.getbbox(s); pad = 6
        im = Image.new("RGBA", (r - l + 2 * pad, b - tp + 2 * pad), col + (0,))
        ImageDraw.Draw(im).text((pad - l, pad - tp), s, font=f, fill=col + (255,))
    elif kind == "p":
        fig = plt.figure(figsize=(24, 3), dpi=100); fig.patch.set_alpha(0)
        kw = {} if "$" in s else {"fontproperties": font_manager.FontProperties(fname=FONTS[fk], size=size * 0.72)}
        txt = fig.text(0.004, 0.45, s, fontsize=size * 0.72, color=tuple(c / 255 for c in col), va="baseline", ha="left", **kw)
        fig.canvas.draw(); bb = txt.get_window_extent(); arr = np.asarray(fig.canvas.buffer_rgba()).copy(); plt.close(fig)
        x0 = max(0, int(bb.x0) - 3); x1 = min(arr.shape[1], int(math.ceil(bb.x1)) + 3)
        im = Image.fromarray(arr[:, x0:x1])
    else:
        fig = plt.figure(figsize=(1, 1), dpi=100)
        fig.text(0, 0, s, fontsize=size * 0.72, color=tuple(c / 255 for c in col))
        buf = io.BytesIO(); fig.savefig(buf, dpi=100, transparent=True, bbox_inches="tight", pad_inches=0.04); plt.close(fig)
        im = Image.open(buf).convert("RGBA")
    _sp[key] = im
    return im

class Frame:
    def __init__(self):
        self.big = Image.new("RGB", (W * S, H * S), BG); self.d = ImageDraw.Draw(self.big); self.sprites = []
    def _p(self, pts): return [(x * S, y * S) for x, y in pts]
    def line(self, pts, col, w=4):
        if len(pts) >= 2: self.d.line(self._p(pts), fill=col, width=max(1, int(w * S)), joint="curve")
    def dashed(self, a, b, col, w=3, on=14, off=10):
        L = math.dist(a, b); n = int(L // (on + off)) + 1
        for i in range(n):
            u0 = i * (on + off) / L; u1 = min(1, (i * (on + off) + on) / L)
            if u0 < 1: self.line([(a[0] + (b[0] - a[0]) * u0, a[1] + (b[1] - a[1]) * u0), (a[0] + (b[0] - a[0]) * u1, a[1] + (b[1] - a[1]) * u1)], col, w)
    def poly(self, pts, fill=None, outline=None, w=2):
        self.d.polygon(self._p(pts), fill=fill)
        if outline: self.line(list(pts) + [pts[0]], outline, w)
    def rect(self, x0, y0, x1, y1, fill, r=0, outline=None, w=3):
        if x1 - x0 < 1: return
        self.d.rounded_rectangle([x0 * S, y0 * S, x1 * S, y1 * S], radius=min(r, (x1 - x0) / 2) * S, fill=fill, outline=outline, width=int(w * S) if outline else 0)
    def circle(self, cx, cy, r, fill=None, outline=None, w=3):
        if r <= 0.3: return
        self.d.ellipse([(cx - r) * S, (cy - r) * S, (cx + r) * S, (cy + r) * S], fill=fill, outline=outline, width=int(w * S) if outline else 0)
    def glow(self, cx, cy, r, col):
        for k, a in ((2.2, 0.08), (1.7, 0.16), (1.3, 0.32)): self.circle(cx, cy, r * k, fill=mix(BG, col, a))
        self.circle(cx, cy, r, fill=col)
    def arrow(self, a, b, col, w=4, head=16):
        self.line([a, b], col, w)
        if math.dist(a, b) < head: return
        ang = math.atan2(b[1] - a[1], b[0] - a[0])
        self.d.polygon(self._p([b, (b[0] - head * math.cos(ang - 0.42), b[1] - head * math.sin(ang - 0.42)),
                                (b[0] - head * math.cos(ang + 0.42), b[1] - head * math.sin(ang + 0.42))]), fill=col)
    def star(self, cx, cy, R, fill):
        if R <= 0.3: return
        pts = [(cx + (R if k % 2 == 0 else R * 0.45) * math.cos(math.radians(-90 + 36 * k)),
                cy + (R if k % 2 == 0 else R * 0.45) * math.sin(math.radians(-90 + 36 * k))) for k in range(10)]
        self.d.polygon(self._p(pts), fill=fill)
    def text(self, xy, s, size, col=WHITE, a=1.0, anchor="mm", fk="R", write=None, rise=0, kind="t"):
        if a <= 0 or (write is not None and write <= 0): return None
        im = sprite(kind, s, size, col, fk)
        self.sprites.append((xy, im, a, anchor, write, rise))
        return im.size
    def tex(self, xy, s, size, col=WHITE, a=1.0, anchor="mm", write=None, rise=0):
        return self.text(xy, s, size, col, a, anchor, write=write, rise=rise, kind="m")
    def p(self, xy, s, size, col=WHITE, a=1.0, anchor="mm", fk="R", write=None, rise=0):
        return self.text(xy, s, size, col, a, anchor, fk, write, rise, kind="p")
    def row(self, cx, y, pieces, a=1.0, write=None, rise=0, gap=0.3):
        ims = [sprite("p", s, sz, c, fk) for s, sz, c, fk in pieces]
        gaps = [gap * pieces[i][1] for i in range(len(pieces) - 1)] + [0]
        total = sum(im.size[0] for im in ims) + sum(gaps); x = cx - total / 2; out = []
        for (s, sz, c, fk), im, g in zip(pieces, ims, gaps):
            w = im.size[0]; wr = None
            if write is not None: wr = clamp((write * total - (x - (cx - total / 2))) / w)
            self.p((x, y), s, sz, c, a, "lm", fk, wr, rise); out.append((x + w / 2, w)); x += w + g
        return out
    def finish(self, fade=1.0):
        img = self.big.reduce(S).convert("RGBA")
        for (x, y), im, a, anchor, write, rise in self.sprites:
            w, h = im.size
            x0 = x - w / 2 if anchor[0] == "m" else (x - w if anchor[0] == "r" else x)
            y0 = y - h / 2 + (1 - eout(a)) * rise
            alpha = np.asarray(im.split()[3], dtype=np.float32) * clamp(a)
            if write is not None and write < 1:
                soft = 60.0; xs = np.arange(w, dtype=np.float32)
                ramp = np.clip((write * (w + soft) - xs) / soft, 0, 1); alpha = alpha * ramp[None, :]
            spr = im.copy(); spr.putalpha(Image.fromarray(alpha.astype(np.uint8)))
            img.alpha_composite(spr, (int(round(x0)), int(round(y0))))
        img = img.convert("RGB")
        if fade < 1: img = Image.blend(Image.new("RGB", (W, H), BG), img, clamp(fade))
        return img

def partial(pts, p):
    if p <= 0 or len(pts) < 2: return pts[:1]
    seg = [math.dist(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]; goal = p * sum(seg); out = [pts[0]]; acc = 0
    for i, L in enumerate(seg):
        if acc + L >= goal:
            u = (goal - acc) / L if L else 0
            out.append((pts[i][0] + u * (pts[i + 1][0] - pts[i][0]), pts[i][1] + u * (pts[i + 1][1] - pts[i][1]))); return out
        out.append(pts[i + 1]); acc += L
    return out

def bez(p0, p1, p2, p3, n=40):
    return [tuple((1 - u) ** 3 * p0[k] + 3 * (1 - u) ** 2 * u * p1[k] + 3 * (1 - u) * u ** 2 * p2[k] + u ** 3 * p3[k] for k in range(len(p0)))
            for u in np.linspace(0, 1, n)]

def wiggle(x0, x1, y, amp, n=300, waves=2.5):
    return [(x0 + (x1 - x0) * u, y + amp * math.sin(u * waves * 2 * math.pi)) for u in np.linspace(0, 1, n)]

def axes(f, o, xend, ytop, p, col=GREY):
    f.arrow(o, (o[0] + (xend - o[0]) * p, o[1]), col, 3, 14 if p > 0.3 else 0)
    f.arrow(o, (o[0], o[1] - (o[1] - ytop) * p), col, 3, 14 if p > 0.3 else 0)

# ---------------- scenes ----------------
def s_title(t, f):
    f.text((960, 460), "We see what we cannot unsee", 100, WHITE, write=ease(prog(t, 0.3, 1.9)))
    f.text((960, 572), "a simple idea about time, life, and what matters", 42, GREY, prog(t, 1.6, 2.4), fk="I")
    pts = wiggle(400, 1520, 780, 38); p = ease(prog(t, 2.0, 5.0)); seg = partial(pts, p); f.line(seg, BLUE, 5)
    for u, r, c in [(0.14, 10, GOLD), (0.37, 22, TEAL), (0.6, 8, PURPLE), (0.84, 16, YELLOW)]:
        if p >= u:
            q = pts[int(u * (len(pts) - 1))]; f.glow(q[0], q[1], r * back(prog(t, 2.0 + 3 * u, 2.4 + 3 * u)), c)
S_TITLE = (s_title, 6.0)

KEYS = [(0.0, [.40, .25, .15, .20]), (6.0, [.30, .20, .35, .15]), (7.6, [.20, .42, .18, .20]), (9.2, [.45, .15, .20, .20])]
def shares_at(t):
    cur = KEYS[0][1]
    for tk, v in KEYS[1:]:
        u = ease(prog(t, tk - 1.1, tk)); cur = [a + (b - a) * u for a, b in zip(cur, v)]
    return cur
def s_share(t, f):
    f.text((960, 160), "You care about many things at once", 64, WHITE, write=ease(prog(t, 0.2, 1.4)))
    a = ease(prog(t, 0.9, 1.9)); x0, x1, y0, y1 = 300, 1620, 360, 500
    if a > 0:
        sh = shares_at(t); x = x0; xr = x0 + (x1 - x0) * a
        for i, s in enumerate(sh):
            w = (x1 - x0) * s; xa, xb = x + 4, min(x + w - 4, xr)
            if xb > xa:
                f.rect(xa, y0, xb, y1, mix(BG, PCOL[i], 0.22), r=10, outline=PCOL[i], w=3)
                f.text(((xa + xb) / 2, (y0 + y1) / 2), PNAMES[i], 38, PCOL[i], prog(t, 1.7, 2.2))
                f.text(((xa + xb) / 2, y0 - 32), f"{round(s * 100)}%", 32, PCOL[i], prog(t, 2.0, 2.5))
            x += w
    f.tex((960, 640), r"$a_{\rm study}+a_{\rm friends}+a_{\rm hobby}+a_{\rm family}=1$", 56, WHITE, write=ease(prog(t, 2.6, 4.0)))
    f.text((960, 800), "There are only so many hours.", 44, WHITE, prog(t, 4.2, 4.9), rise=12)
    f.text((960, 865), "When one share grows, another must shrink.", 44, YELLOW, prog(t, 4.8, 5.5), rise=12)
S_SHARE = (s_share, 10.5)

def s_long(t, f):
    f.text((960, 120), "Does lasting longer mean mattering more?", 60, WHITE, write=ease(prog(t, 0.2, 1.4)))
    o = (340, 860); xe, yt = 1620, 300
    axes(f, o, xe, yt, ease(prog(t, 0.8, 1.8)))
    f.text((xe, 905), "how long it lasted", 36, GREY, prog(t, 1.6, 2.1), anchor="rm", fk="I")
    f.text((360, 268), "how much it mattered later", 36, GREY, prog(t, 1.6, 2.1), anchor="lm", fk="I")
    rng = np.random.default_rng(3)
    for k, (x, y) in enumerate(zip(rng.uniform(450, 1500, 9), rng.uniform(380, 800, 9))):
        f.circle(x, y, 7 * back(prog(t, 2.0 + 0.08 * k, 2.4 + 0.08 * k)), fill=DIM)
    gp = ease(prog(t, 5.0, 6.0))
    if gp > 0: f.dashed(o, (o[0] + (1560 - o[0]) * gp, o[1] - (o[1] - 340) * gp), GREY, 3)
    f.text((1560, 300), "if length decided meaning", 32, GREY, prog(t, 5.8, 6.3), anchor="rm", fk="I")
    f.glow(1450, 795, 14 * back(prog(t, 2.9, 3.4)), GOLD)
    f.text((1450, 745), "a year of a class you forgot", 36, GOLD, prog(t, 3.1, 3.6), anchor="mm")
    f.glow(430, 380, 20 * back(prog(t, 3.9, 4.4)), TEAL)
    f.text((470, 380), "10 minutes with a teacher who believed in you", 36, TEAL, prog(t, 4.1, 4.6), anchor="lm")
    f.text((960, 1000), "Lasting long is not the same as mattering.", 46, YELLOW, prog(t, 7.0, 7.8), rise=12)
S_LONG = (s_long, 10.5)

LAM, MU = 0.5, 0.01
TSTAR = math.log(LAM / MU) / (LAM - MU); CMAX = (math.exp(-MU * TSTAR) - math.exp(-LAM * TSTAR)) / (LAM - MU)
def s_clocks(t, f):
    f.text((960, 120), "A feeling is fast. Meaning is slow.", 64, WHITE, write=ease(prog(t, 0.2, 1.4)))
    o = (260, 830); xe, yt = 1640, 300
    axes(f, o, xe, yt, ease(prog(t, 0.8, 1.6)))
    f.text((xe, 875), "days after it happens", 34, GREY, prog(t, 1.4, 1.9), anchor="rm", fk="I")
    X = lambda d: o[0] + d / 90 * (1580 - o[0]); Y = lambda v: o[1] - v * (o[1] - 340)
    days = np.linspace(0, 90, 500)
    fe = [(X(d), Y(math.exp(-LAM * d))) for d in days]
    ce = [(X(d), Y((math.exp(-MU * d) - math.exp(-LAM * d)) / (LAM - MU) / CMAX)) for d in days]
    pf = ease(prog(t, 1.6, 3.2)); f.line(partial(fe, pf), RED, 6)
    if 0 < pf < 1: q = partial(fe, pf)[-1]; f.glow(q[0], q[1], 7, RED)
    f.text((X(4.5), Y(0.30)), "feeling", 40, RED, prog(t, 2.4, 2.9), anchor="lm")
    f.tex((X(4.5) + 10, Y(0.30) + 55), r"$E(t)=e^{-\lambda t}$", 40, RED, anchor="lm", write=ease(prog(t, 2.8, 3.6)))
    pc = ease(prog(t, 3.6, 6.6)); f.line(partial(ce, pc), BLUE, 7)
    if 0 < pc < 1: q = partial(ce, pc)[-1]; f.glow(q[0], q[1], 8, BLUE)
    f.text((X(30), Y(0.82) - 48), "meaning", 40, BLUE, prog(t, 5.0, 5.5))
    f.tex((X(62), Y(0.66) - 95), r"$C(t)\propto e^{-\mu t}-e^{-\lambda t}$", 40, BLUE, write=ease(prog(t, 5.6, 6.6)))
    f.tex((960, 990), r"$\lambda \gg \mu$:  the feeling fades in days; the meaning can grow later, and stay.", 44, YELLOW, prog(t, 7.4, 8.2), rise=12)
S_CLOCKS = (s_clocks, 11.0)

def s_pull(t, f):
    f.text((960, 120), "Every experience changes how the next one lands", 60, WHITE, write=ease(prog(t, 0.2, 1.5)))
    past = [("played on a team", 420, 360, 1.0, 0.9, GOLD), ("watched a match once", 330, 560, 0.35, 0.8, TEAL), ("went to a concert", 470, 700, 0.7, 0.1, PURPLE)]
    k = (1380, 560)
    f.text((380, 260), "your past", 36, GREY, prog(t, 0.8, 1.3), fk="I")
    for i, (lab, x, y, C, sim, col) in enumerate(past):
        ts = 1.0 + 0.35 * i
        f.glow(x, y, (10 + 26 * C) * back(prog(t, ts, ts + 0.5)), col)
        f.text((x, y + 30 + 26 * C + 10), lab, 32, col, prog(t, ts + 0.2, ts + 0.6), fk="I")
    f.glow(k[0], k[1], 16 * back(prog(t, 2.4, 2.9)), WHITE)
    f.text((k[0], k[1] - 165), "something new:", 34, GREY, prog(t, 2.6, 3.1), fk="I")
    f.text((k[0], k[1] - 125), "watching a match", 38, WHITE, prog(t, 2.6, 3.1))
    total = 0
    for i, (lab, x, y, C, sim, col) in enumerate(past):
        p = ease(prog(t, 3.3 + 0.6 * i, 4.0 + 0.6 * i)); wgt = sim * C
        if p > 0:
            a0 = (x + 36 + 26 * C, y); b0 = (k[0] - 40, k[1])
            f.line([a0, (a0[0] + (b0[0] - a0[0]) * p, a0[1] + (b0[1] - a0[1]) * p)], mix(BG, col, 0.35 + 0.65 * wgt), max(1.5, 14 * wgt))
        total += wgt * ease(prog(t, 4.0 + 0.6 * i, 4.6 + 0.6 * i))
    if t > 4.0:
        r = 16 + 34 * total; f.glow(k[0], k[1], r, mix(WHITE, YELLOW, clamp(total / 1.0)))
    f.text((900, 330), "similar, and it mattered", 30, GOLD, prog(t, 4.0, 4.5), fk="I")
    f.text((900, 680), "not similar", 30, PURPLE, prog(t, 5.2, 5.7), fk="I")
    f.tex((960, 865), r"$\alpha_k=\alpha_0+\gamma\sum_{j<k}\mathrm{sim}(j,k)\,C_j$", 62, WHITE, write=ease(prog(t, 6.4, 8.0)))
    f.tex((960, 995), r"$\gamma=0$: the past has no pull.      $\gamma>0$: we see what we cannot unsee.", 42, YELLOW, prog(t, 9.0, 9.8), rise=12)
S_PULL = (s_pull, 14.0)

FSH = {0: [.10, .30, .40, .20], .25: [.25, .40, .20, .15], .5: [.50, .15, .20, .15], .75: [.30, .40, .15, .15], 1: [.20, .35, .30, .15]}
def s_shape(t, f):
    f.text((960, 90), "Your life as a shape", 60, WHITE, write=ease(prog(t, 0.2, 1.3)))
    LEN, H0, D0, LAMB = 3.0, 1.35, 0.95, 0.55
    yaw = math.radians(-36 + 22 * ease(t / 14.0)); pitch = math.radians(18)
    sc = 300; c3 = (LEN / 2, H0 / 2, D0 / 2); scx, scy = 960, 600
    def P(x, y, z):
        x, y, z = x - c3[0], y - c3[1], z - c3[2]
        x1 = x * math.cos(yaw) + z * math.sin(yaw); z1 = -x * math.sin(yaw) + z * math.cos(yaw)
        y1 = y * math.cos(pitch) + z1 * math.sin(pitch)
        return (scx + sc * x1, scy - sc * y1)
    Ht = lambda u: H0 * (1 - LAMB * u); Dp = lambda u: D0 * (1 - LAMB * u)
    ax = ease(prog(t, 0.6, 1.6))
    def axis(tip):
        a = P(0, 0, 0); b = P(tip[0] * ax, tip[1] * ax, tip[2] * ax); f.arrow(a, b, GREY, 3, 14 if ax > 0.3 else 0); return b
    bx = axis((LEN + 0.45, 0, 0)); by = axis((0, H0 + 0.5, 0)); bz = axis((0, 0, D0 + 0.6))
    f.text((bx[0] + 14, bx[1] + 4), "your whole life", 32, GREY, prog(t, 1.4, 1.9), anchor="lm", fk="I")
    f.text((by[0] + 16, by[1] - 4), "time you spend", 32, GREY, prog(t, 1.4, 1.9), anchor="lm", fk="I")
    f.text((bz[0] - 12, bz[1] - 16), "things you made", 32, GREY, prog(t, 1.4, 1.9), anchor="rm", fk="I")
    C = lambda u, top, back: (LEN * u, Ht(u) if top else 0.0, Dp(u) if back else 0.0)
    ep = ease(prog(t, 1.2, 2.8))
    if ep > 0:
        f.poly([P(*C(0, 0, 0)), P(*C(0, 1, 0)), P(*C(0, 1, 1)), P(*C(0, 0, 1))], fill=mix(BG, WHITE, 0.05 * ep))
        f.poly([P(*C(0, 1, 0)), P(*C(1, 1, 0)), P(*C(1, 1, 1)), P(*C(0, 1, 1))], fill=mix(BG, WHITE, 0.035 * ep))
    ts = sorted(FSH); fill = ease(prog(t, 2.6, 3.6))
    bef = lambda i, u: sum(FSH[u][:i])
    if fill > 0:
        for i in range(4):
            lo = [P(LEN * u, Ht(u) * bef(i, u), 0) for u in ts]; hi = [P(LEN * u, Ht(u) * (bef(i, u) + FSH[u][i]), 0) for u in ts]
            f.poly(lo + hi[::-1], fill=mix(BG, PCOL[i], 0.28 * fill))
            if i < 3: f.line(hi, mix(BG, PCOL[i], fill), 2)
            q = P(LEN + 0.06, Ht(1) * (bef(i, 1) + FSH[1][i] / 2), 0); f.text((q[0] + 6, q[1]), PNAMES[i], 28, PCOL[i], prog(t, 3.2, 3.7), anchor="lm")
    if ep > 0:
        hidden = [((0, 0, 1), (1, 0, 1)), ((1, 0, 1), (1, 1, 1)), ((1, 0, 0), (1, 0, 1))]
        seen = [((0, 1, 1), (1, 1, 1)), ((0, 0, 1), (0, 1, 1)), ((0, 0, 0), (0, 0, 1)), ((0, 1, 0), (0, 1, 1)), ((1, 1, 0), (1, 1, 1))]
        front = [((0, 0, 0), (1, 0, 0)), ((1, 0, 0), (1, 1, 0)), ((1, 1, 0), (0, 1, 0)), ((0, 1, 0), (0, 0, 0))]
        for grp, col, w in ((hidden, DIM, 2), (seen, GREY, 2), (front, WHITE, 3)):
            for a_, b_ in grp: f.line(partial([P(*C(*a_)), P(*C(*b_))], ep), col, w)
    o2 = P(0, 0, 0); f.star(o2[0], o2[1], 20 * back(prog(t, 0.5, 1.0)), YELLOW)
    f.text((o2[0] - 30, o2[1] + 30), "you", 30, YELLOW, prog(t, 0.7, 1.2), fk="I")
    f.text((960, 172), "Each strip is something you care about. Its height is how much of your time it gets.", 34, GREY, prog(t, 3.4, 4.1), fk="I")
    exps = [(0.25, 1, 0.85), (0.5, 0, 0.35), (0.75, 1, 0.7)]
    dom = lambda u: max(range(4), key=lambda i: FSH[u][i])
    mid3 = lambda i, u: (LEN * u, Ht(u) * (bef(i, u) + FSH[u][i] / 2), 0.0)
    P3 = [mid3(dom(0), 0)] + [mid3(i, u) for u, i, s in exps] + [mid3(dom(1), 1)]
    pts3 = []
    for a_, b_ in zip(P3[:-1], P3[1:]):
        xm = (a_[0] + b_[0]) / 2; pts3 += bez(a_, (xm, a_[1], 0), (xm, b_[1], 0), b_, 30)
    pts2 = [P(*q) for q in pts3]; pp = ease(prog(t, 4.4, 8.4)); f.line(partial(pts2, pp), WHITE, 5)
    if 0 < pp < 1: q = partial(pts2, pp)[-1]; f.glow(q[0], q[1], 7, WHITE)
    for kk, (u, i, s) in enumerate(exps):
        fr_ = (kk + 1) / (len(P3) - 1)
        if pp >= fr_ - 1e-6:
            q = P(*mid3(i, u)); ts0 = 4.4 + 4 * fr_; f.glow(q[0], q[1], (8 + 22 * s) * back(prog(t, ts0, ts0 + 0.5)), YELLOW)
    f.text((960, 1010), "Meaning is not on any axis. It is the size of the dots.", 46, YELLOW, prog(t, 9.4, 10.2), rise=12)
S_SHAPE = (s_shape, 14.0)

def s_found(t, f):
    f.text((960, 130), "What real data says so far", 64, WHITE, write=ease(prog(t, 0.2, 1.3)))
    rows = [(1.0, True, "What matters grabs your attention, and attention makes it matter more."),
            (2.8, True, "Getting things done does not automatically make them meaningful."),
            (4.6, True, "Old memories settle: their meaning changes less over time."),
            (6.4, False, "Does your past change how you see new things? Not tested yet.")]
    for k, (ts_, ok, s) in enumerate(rows):
        y = 320 + 150 * k; c = GREEN if ok else YELLOW; r = 30 * back(prog(t, ts_, ts_ + 0.5))
        f.circle(230, y, r, outline=c, w=4)
        if ok and r > 18: f.line(partial([(216, y + 1), (227, y + 13), (247, y - 13)], ease(prog(t, ts_ + 0.3, ts_ + 0.7))), c, 5)
        if not ok: f.text((230, y + 2), "?", 44, c, prog(t, ts_ + 0.3, ts_ + 0.7), fk="B")
        f.text((300, y), s, 42, WHITE if ok else YELLOW, anchor="lm", write=ease(prog(t, ts_ + 0.2, ts_ + 1.4)))
    f.text((960, 985), "from real studies that followed hundreds of people over weeks and years", 32, GREY, prog(t, 8.2, 8.9), fk="I")
S_FOUND = (s_found, 11.5)

def s_gdef(t, f):
    f.row(960, 110, [("What is", 64, WHITE, "R"), (r"$\gamma\,$?", 78, YELLOW, "R")], write=ease(prog(t, 0.2, 1.2)), gap=0.22)
    f.text((960, 190), "(say it: gamma)", 34, GREY, prog(t, 1.0, 1.5), fk="I")
    eq = f.row(960, 330, [(r"$\alpha_k$", 66, WHITE, "R"), (r"$=$", 66, GREY, "R"), (r"$\alpha_0$", 66, BLUE, "R"), (r"$+$", 66, GREY, "R"),
                          (r"$\gamma$", 66, YELLOW, "R"), (r"$\times$", 66, GREY, "R"), (r"$\sum_{j<k}\mathrm{sim}(j,k)\,C_j$", 66, GOLD, "R")],
               write=ease(prog(t, 1.4, 3.0)), gap=0.42)
    rows = [(3.2, r"$\alpha_k$", WHITE, "how much a new thing grabs your attention"),
            (4.2, r"$\alpha_0$", BLUE, "how much it would grab anyone"),
            (5.2, r"$\sum\,\mathrm{sim}\cdot C$", GOLD, "your past that was similar, and mattered"),
            (6.4, r"$\gamma$", YELLOW, "the dial: how strongly that past pulls on you")]
    hl = ease(prog(t, 7.2, 7.9))
    if hl > 0:
        gx = eq[4][0]; f.circle(gx, 324, 42 * back(hl), outline=YELLOW, w=3)
        f.rect(600, 785 - 44, 600 + 1030 * hl, 785 + 44, None, r=14, outline=YELLOW, w=3)
    for k, (ts_, sym, col, txt) in enumerate(rows):
        y = 530 + 85 * k
        f.p((700, y), sym, 50, col, prog(t, ts_, ts_ + 0.5), anchor="rm")
        f.p((750, y), txt, 42, col if col != WHITE else WHITE, anchor="lm", write=ease(prog(t, ts_ + 0.1, ts_ + 1.1)))
    f.text((960, 960), "So what happens when you turn the dial?", 46, YELLOW, prog(t, 8.6, 9.3), rise=12)
S_GDEF = (s_gdef, 11.0)

def s_dial(t, f):
    f.row(960, 100, [("Turn the dial", 60, WHITE, "R"), (r"$\gamma$", 72, YELLOW, "R")], write=ease(prog(t, 0.2, 1.2)), gap=0.3)
    g = ease(prog(t, 5.2, 8.6))
    sa = ease(prog(t, 0.8, 1.6)); x0, x1, ys = 660, 1260, 230
    if sa > 0:
        f.line([(x0, ys), (x0 + (x1 - x0) * sa, ys)], GREY, 5)
        if g > 0: f.line([(x0, ys), (x0 + (x1 - x0) * g, ys)], YELLOW, 7)
        f.glow(x0 + (x1 - x0) * g, ys, 15 * back(prog(t, 1.2, 1.7)), YELLOW)
        f.text((x0, ys + 42), "0", 32, GREY, sa); f.text((x1, ys + 42), "big", 32, GREY, sa, fk="I")
        f.p((x1 + 60, ys), r"$\gamma = %.1f$" % (round(g * 10) / 10), 48, YELLOW, sa, anchor="lm")
    people = [(560, "Mia", "played on a team for years", 1.0), (1360, "Leo", "has never played", 0.0)]
    for k, (x, name, desc, past) in enumerate(people):
        ts_ = 1.4 + 0.3 * k
        f.text((x, 380), name, 46, WHITE, prog(t, ts_, ts_ + 0.5))
        f.text((x, 430), desc, 32, GREY, prog(t, ts_ + 0.1, ts_ + 0.6), fk="I")
        pa = back(prog(t, ts_ + 0.4, ts_ + 0.9))
        if past > 0: f.glow(x, 530, 30 * pa, GOLD)
        elif pa > 0: f.circle(x, 530, 30 * pa, outline=DIM, w=3)
        w_ = g * past
        R = (22 + 48 * w_) * back(prog(t, ts_ + 0.7, ts_ + 1.2))
        f.glow(x, 750, R, mix(WHITE, YELLOW, w_))
        if w_ > 0.02: f.arrow((x, 566), (x, 750 - R - 6), mix(BG, GOLD, 0.3 + 0.7 * w_), 2 + 10 * w_, 10 + 14 * w_)
    f.text((960, 530), "their past", 32, GREY, prog(t, 2.2, 2.7), fk="I")
    f.text((960, 750), "the same new thing: a match", 32, GREY, prog(t, 2.4, 2.9), fk="I")
    c1 = min(prog(t, 2.8, 3.4), 1 - prog(t, 4.8, 5.2)); c2 = prog(t, 8.8, 9.5)
    f.text((960, 960), "Dial at 0: the match grabs them both the same.", 46, WHITE, c1, rise=12)
    f.text((960, 940), "Dial up: the match grabs Mia far more than Leo.", 46, YELLOW, c2, rise=12)
    f.text((960, 1005), "Her past changes what she sees. She cannot unsee it.", 40, WHITE, prog(t, 9.6, 10.3), rise=12)
S_DIAL = (s_dial, 13.0)

def s_end(t, f):
    f.text((960, 120), "We see what we cannot unsee.", 74, WHITE, write=ease(prog(t, 0.2, 1.5)))
    f.row(960, 240, [("The big question: how big is", 52, WHITE, "R"), (r"$\gamma$", 62, YELLOW, "R"), ("?", 52, WHITE, "R")], prog(t, 1.6, 2.3), rise=12, gap=0.2)
    f.text((960, 330), "Nobody has measured it yet. Here is how you could:", 38, GREY, prog(t, 2.6, 3.2), fk="I")
    steps = [(3.4, "Follow the same people for months."), (4.6, "Write down what mattered to them, and when."), (5.8, "Check: do similar new things grab them more?")]
    for k, (ts_, s) in enumerate(steps):
        y = 450 + 95 * k; r = 28 * back(prog(t, ts_, ts_ + 0.5))
        f.circle(470, y, r, outline=BLUE, w=4); f.text((470, y), str(k + 1), 36, BLUE, prog(t, ts_ + 0.2, ts_ + 0.6), fk="B")
        f.text((530, y), s, 42, WHITE, anchor="lm", write=ease(prog(t, ts_ + 0.2, ts_ + 1.3)))
    f.row(960, 770, [("If yes:", 44, GREEN, "R"), (r"$\gamma>0$,", 48, YELLOW, "R"), ("and the idea holds.", 44, WHITE, "R")], prog(t, 7.2, 7.9), rise=12, gap=0.25)
    f.row(960, 845, [("If no:", 44, RED, "R"), (r"$\gamma=0$,", 48, YELLOW, "R"), ("and the idea is wrong.", 44, WHITE, "R")], prog(t, 8.0, 8.7), rise=12, gap=0.25)
    f.text((960, 1000), "Analysis, code and animation by Claude", 30, GREY, prog(t, 9.6, 10.3), fk="I")
S_END = (s_end, 13.0)

SCENES = [S_TITLE, S_SHARE, S_LONG, S_CLOCKS, S_PULL, S_SHAPE, S_FOUND, S_GDEF, S_DIAL, S_END]

def frame(i, t):
    fn, dur = SCENES[i]; f = Frame(); fn(t, f)
    fade = min(1.0, t / 0.4, (dur - t) / 0.4) if i > 0 else min(1.0, (dur - t) / 0.4)
    return f.finish(max(fade, 0.0))

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "list":
        tot = 0
        for i, (fn, d) in enumerate(SCENES): print(i, fn.__name__, d, round(tot, 1)); tot += d
        print("total", tot)
    elif mode == "still":
        frame(int(sys.argv[2]), float(sys.argv[3])).save(sys.argv[4])
    elif mode == "render":
        i = int(sys.argv[2]); outdir = sys.argv[3]; fn, dur = SCENES[i]
        tmp = os.path.join(outdir, f"scene{i:02d}.part.mp4"); final = os.path.join(outdir, f"scene{i:02d}.mp4")
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
               "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-r", str(FPS), tmp]
        pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        for k in range(int(round(dur * FPS))):
            pr.stdin.write(frame(i, k / FPS).tobytes())
        pr.stdin.close()
        if pr.wait() == 0: os.replace(tmp, final)
        else: sys.exit(1)
