"""Companion video v2: four true stories tied back to 'We see what we cannot unsee'. Written by Claude.
Usage: python3 famous.py list | still <i:t,...> <dir> | render <i> <outdir>"""
import sys, os, subprocess
import os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lv_common import *
from lv_part1 import partcard
from stories import person, bubble, story_header, tie, house

LMD = os.environ.get("LM_FONT_DIR", "/usr/share/texmf/fonts/opentype/public/lm/")
FONTS["S"] = LMD + "lmsans10-regular.otf"; FONTS["M"] = LMD + "lmmono10-regular.otf"; FONTS["BI"] = LMD + "lmroman10-bolditalic.otf"

# ---------- icons ----------
def crown(f, cx, cy, s, col, a=1.0):
    if a <= 0: return
    c = mix(BG, col, a); xs = np.linspace(cx - s, cx + s, 9)
    zig = [(x, cy - (0.75 * s if k % 2 == 0 else 0.2 * s)) for k, x in enumerate(xs)]
    f.poly([(cx - s, cy + 0.35 * s)] + zig + [(cx + s, cy + 0.35 * s)], fill=mix(BG, col, 0.35 * a), outline=c, w=3)
    for k, x in enumerate(xs):
        if k % 2 == 0: f.circle(x, cy - 0.75 * s, 0.09 * s, fill=c)

def tub(f, x0, x1, y0, y1, level, a=1.0):
    if a <= 0: return
    if level < y1: f.rect(x0 + 4, level, x1 - 4, y1 - 4, mix(BG, BLUE, 0.35 * a), r=10)
    f.line([(x0, y0), (x0, y1 - 20), (x0 + 20, y1), (x1 - 20, y1), (x1, y1 - 20), (x1, y0)], mix(BG, WHITE, 0.8 * a), 5)

def bowl(f, cx, cy, w, a=1.0):
    if a <= 0: return
    f.rect(cx - w / 2 + 4, cy - 70, cx + w / 2 - 4, cy - 4, mix(BG, BLUE, 0.35 * a), r=8)
    f.line([(cx - w / 2, cy - 76), (cx - w / 2, cy), (cx + w / 2, cy), (cx + w / 2, cy - 76)], mix(BG, WHITE, 0.8 * a), 4)

def book(f, cx, cy, s, col, a=1.0):
    if a <= 0: return
    c = mix(BG, col, a)
    f.rect(cx - 0.8 * s, cy - s, cx + 0.8 * s, cy + s, mix(BG, col, 0.18 * a), r=8, outline=c, w=3)
    f.line([(cx - 0.62 * s, cy - s), (cx - 0.62 * s, cy + s)], c, 3)

def dish(f, cx, cy, r, zone, a=1.0, seed=7):
    if a <= 0: return
    f.circle(cx, cy, r, fill=mix(BG, WHITE, 0.05 * a), outline=mix(BG, WHITE, 0.7 * a), w=4)
    mx, my = cx - 0.35 * r, cy - 0.3 * r
    rng = np.random.default_rng(seed)
    for _ in range(70):
        ang, rad = rng.uniform(0, 2 * np.pi), r * 0.88 * np.sqrt(rng.uniform())
        x, y = cx + rad * np.cos(ang), cy + rad * np.sin(ang); d = math.hypot(x - mx, y - my)
        vis = a * (1 - clamp((zone * 0.45 * r - d) / 20)) if d > 0.18 * r else 0
        if vis > 0.02: f.circle(x, y, 6, fill=mix(BG, GOLD, 0.8 * vis))
    f.circle(mx, my, 0.17 * r, fill=mix(BG, TEAL, 0.85 * a))
    if zone > 0: ring(f, mx, my, 0.45 * r * zone, YELLOW, 0.5 * a * min(1, zone), 2)

def computer(f, cx, cy, s, col, a=1.0):
    if a <= 0: return
    c = mix(BG, col, a)
    f.rect(cx - s, cy - 1.1 * s, cx + s, cy + 0.7 * s, mix(BG, col, 0.12 * a), r=14, outline=c, w=3)
    f.rect(cx - 0.8 * s, cy - 0.9 * s, cx + 0.8 * s, cy + 0.3 * s, mix(BG, WHITE, 0.9 * a), r=6)
    f.rect(cx - 0.5 * s, cy + 0.7 * s, cx + 0.5 * s, cy + 0.85 * s, c, r=4)

# ---------- scenes ----------
def s_open(t, f):
    f.text((960, 400), "We see what we cannot unsee", 96, WHITE, write=ease(prog(t, 0.3, 1.9)))
    f.text((960, 510), "four true stories", 46, GREY, prog(t, 1.8, 2.5), fk="I")
    icons = [(560, crown, GOLD), (840, book, BLUE), (1120, None, TEAL), (1400, computer, PURPLE)]
    for k, (x, fn, col) in enumerate(icons):
        a = prog(t, 2.6 + 0.5 * k, 3.1 + 0.5 * k)
        if k == 0: crown(f, x, 700, 50, col, a)
        elif k == 1: book(f, x, 690, 50, col, a)
        elif k == 2: dish(f, x, 690, 60, 1.0, a)
        else: computer(f, x, 700, 50, col, a)
    f.text((960, 900), "Real events, retold briefly. Where a story may be legend, the video says so.", 30, GREY, prog(t, 5.0, 5.7), fk="I")
S_OPEN = (s_open, 8.5)

def s_arch(t, f):
    story_header(f, "Story 1: Archimedes and the crown")
    a1 = win(t, 0.4, 9.4)
    person(f, 420, 420, 28, GOLD, a1); f.text((420, 490), "King Hiero II", 32, GOLD, a1)
    crown(f, 960, 380, 110, GOLD, a1); f.text((960, 470), "a gold crown, made for the gods", 30, GREY, a1, fk="I")
    bubble(f, 230, 220, 860, 300, (400, 340), "Pure gold, or mixed with silver?", win(t, 1.6, 9.4))
    ax = 1500; pa = prog(t, 4.6, 5.2) * (1 - prog(t, 9.2, 9.6))
    person(f, ax, 420, 28, BLUE, pa); f.text((ax, 490), "Archimedes", 32, BLUE, pa)
    tb = win(t, 6.0, 20.0)
    if tb > 0:
        bx = 1500 if t < 9.6 else 1240
        f.circle(bx, 220, 70, fill=mix(BG, WHITE, 0.08 * tb), outline=mix(BG, WHITE, 0.7 * tb), w=3)
        crown(f, bx, 232, 40, GOLD, tb); f.text((bx + 34, 182), "?", 40, YELLOW, tb, fk="B")
        for k, (dx, dy, r) in enumerate([(-60, 300, 10), (-90, 340, 7)]):
            if t < 9.6: f.circle(bx + dx + 30, 160 + dy - 150, r, fill=mix(BG, WHITE, 0.7 * tb))
    a2 = win(t, 9.6, 20.0)
    if a2 > 0:
        x0, x1, y0, y1 = 700, 1220, 520, 780
        step = ease(prog(t, 10.4, 12.6)); level = 560 - 40 * ease(prog(t, 11.4, 13.0))
        tub(f, x0, x1, y0, y1, max(level, y0 + 2), a2)
        py = 330 + 260 * step; person(f, 960, py, 30, BLUE, a2)
        if level < y0 + 6:
            for k in range(14):
                u = ((t - 12.4) * 1.3 + k / 14) % 1; side = -1 if k % 2 else 1
                x = (x0 - 10 - 60 * u if side < 0 else x1 + 10 + 60 * u); y = y0 + 260 * u * u
                f.circle(x, y, 5, fill=mix(BG, BLUE, a2 * (1 - u)))
        f.text((960, 250), "Eureka!", 90, YELLOW, prog(t, 14.4, 14.9) * a2, fk="BI")
        f.text((960, 330), "I have found it!", 32, GREY, prog(t, 14.8, 15.3) * a2, fk="I")
    a3 = prog(t, 20.2, 20.8)
    if a3 > 0:
        for k, (cx, lab, spill, ts) in enumerate([(640, "pure gold, same weight", 30, 21.0), (1280, "the crown", 60, 22.4)]):
            bowl(f, cx, 640, 260, a3)
            if k == 0: f.rect(cx - 24, 600, cx + 24, 636, mix(BG, GOLD, a3), r=4)
            else: crown(f, cx, 612, 40, GOLD, a3)
            sp = ease(prog(t, ts, ts + 1.4))
            if sp > 0: f.rect(cx + 135, 640 - 8, cx + 135 + spill * 1.6 * sp, 640, mix(BG, BLUE, 0.7), r=4)
            f.text((cx, 700), lab, 32, WHITE, a3)
            f.text((cx + 135 + spill * 0.8, 600), "spills" if k == 0 else "spills more", 26, BLUE, prog(t, ts + 1.2, ts + 1.7), fk="I")
        f.text((960, 800), "more water spilled = more volume = not pure gold", 34, YELLOW, prog(t, 24.0, 24.7))
    cap(f, "Syracuse, 3rd century BC. King Hiero suspects his new gold crown has been mixed with silver.", win(t, 0.8, 5.0), y=975, size=36)
    cap(f, "He asks Archimedes to find out without damaging it. The problem stays with him.", win(t, 5.2, 9.4), y=975, size=36)
    cap(f, "Then, getting into a full bath, he watches the water spill over the side.", win(t, 9.8, 14.6), y=975, size=36)
    cap(f, "People had watched bathwater spill forever. Carrying this problem, he saw a way to measure the crown.", win(t, 14.8, 20.0), y=975, size=36, col=YELLOW)
    cap(f, "Equal weights of gold and crown, each lowered into a full bowl: the crown spills more water.", win(t, 20.2, 27.4), y=975, size=36)
    cap(f, "As told by the Roman writer Vitruvius, about two centuries later. It may be partly legend.", prog(t, 27.6, 28.2), y=975, size=32, col=GREY, fk="I")
S_ARCH = (s_arch, 32.0)
S_C1 = partcard("Story 1", "Archimedes and the crown", "a problem you carry changes what you see")
S_T1 = (tie(1, ["An ordinary event became a discovery because of the problem he was already carrying.", "The past did not just sit in memory. It became the lens."],
            "He could not unsee the crown in the bathwater.", ["H6: the past changes how the new is seen"]), 13.0)

def s_dw(t, f):
    story_header(f, "Story 2: Darwin, Wallace and the same book")
    ba = prog(t, 0.6, 1.2)
    book(f, 960, 470, 90, WHITE, ba); f.text((1000, 430), "Malthus", 32, WHITE, ba, fk="B"); f.text((1000, 480), "1798", 28, GREY, ba)
    f.text((960, 600), "An Essay on the Principle of Population", 28, GREY, ba, fk="I")
    for k in range(9):
        ang = math.radians(200 + 140 * k / 8); x, y = 960 + 300 * math.cos(ang), 470 + 210 * math.sin(ang)
        ra = prog(t, 2.2 + 0.15 * k, 2.6 + 0.15 * k)
        if ra > 0: f.line([(x, y + 20), (960 + (x - 960) * 0.35, 470 + (y - 470) * 0.35)], mix(BG, DIM, ra), 2); person(f, x, y, 11, GREY, ra * 0.8)
    f.text((960, 210), "many readers", 28, GREY, prog(t, 3.6, 4.1), fk="I")
    da = prog(t, 7.0, 7.6)
    person(f, 330, 470, 26, BLUE, da); f.text((330, 532), "Charles Darwin", 32, BLUE, da)
    pts = wiggle(120, 560, 700, 16, waves=3); pp = ease(prog(t, 7.4, 10.0)); f.line(partial(pts, pp), mix(BG, BLUE, 0.8), 4)
    for u in (0.2, 0.45, 0.7, 0.9):
        if pp >= u: q = pts[int(u * (len(pts) - 1))]; f.circle(q[0], q[1], 7, fill=BLUE)
    f.text((340, 750), "five years on HMS Beagle, 1831 to 1836", 26, GREY, prog(t, 9.6, 10.2), fk="I")
    l1 = ease(prog(t, 12.4, 13.6))
    if l1 > 0: f.line([(380, 470), (380 + (870 - 380) * l1, 470)], BLUE, 8)
    g1 = prog(t, 14.0, 14.8)
    f.glow(330, 330, 22 * back(g1), YELLOW); f.text((330, 280), "natural selection", 30, YELLOW, g1, fk="I")
    f.text((330, 370), "1838", 26, GREY, g1, fk="I")
    wa = prog(t, 17.2, 17.8)
    person(f, 1590, 470, 26, TEAL, wa); f.text((1590, 532), "Alfred Russel Wallace", 32, TEAL, wa)
    for k in range(10):
        x = 1380 + 44 * k; a = prog(t, 17.6 + 0.12 * k, 18.0 + 0.12 * k)
        if a > 0: f.circle(x, 700 + 10 * math.sin(k), 7, fill=mix(BG, TEAL, a))
    f.text((1580, 750), "years collecting in the Amazon and the Malay Archipelago", 26, GREY, prog(t, 18.8, 19.4), fk="I")
    l2 = ease(prog(t, 21.0, 22.2))
    if l2 > 0: f.line([(1540, 470), (1540 - (1540 - 1050) * l2, 470)], TEAL, 8)
    g2 = prog(t, 23.2, 24.0)
    f.glow(1590, 330, 22 * back(g2), YELLOW); f.text((1590, 280), "natural selection", 30, YELLOW, g2, fk="I")
    f.text((1590, 370), "1858", 26, GREY, g2, fk="I")
    cap(f, "1798: Thomas Malthus argues that populations grow faster than their food supply. The book is widely read.", win(t, 0.8, 6.8), y=975, size=36)
    cap(f, "Charles Darwin comes home from five years on the Beagle, full of observations he cannot yet explain.", win(t, 7.0, 12.0), y=975, size=36)
    cap(f, "In 1838 he reads Malthus, as he put it, for amusement. Suddenly he has a theory to work with.", win(t, 12.2, 17.0), y=975, size=36)
    cap(f, "In 1858, Alfred Russel Wallace, after years of collecting in the tropics, lies sick with fever and recalls the same book.", win(t, 17.2, 23.0), y=975, size=36)
    cap(f, "He sees the same idea: natural selection. That July, their papers are read together in London.", win(t, 23.2, 28.0), y=975, size=36)
    cap(f, "Same book, many readers. Only those with a similar past saw it.", prog(t, 28.2, 28.9), y=975, size=40, col=YELLOW)
S_DW = (s_dw, 33.0)
S_C2 = partcard("Story 2", "Darwin, Wallace and the same book", "a similar past sees the same thing")
S_T2 = (tie(2, ["The same book landed differently on different readers.", "It mattered most to the two whose past was most like what it described."],
            "Neither could unsee years of field notes in Malthus's numbers.", ["H6: a similar past, and how much it mattered"]), 13.0)

XF = lambda yr: 1100 + (yr - 1928) / 17 * 680
def s_fleming(t, f):
    story_header(f, "Story 3: Fleming's moldy dish")
    fa = prog(t, 0.4, 1.0)
    person(f, 180, 420, 26, BLUE, fa); f.text((180, 482), "Alexander Fleming", 30, BLUE, fa)
    zone = ease(prog(t, 3.4, 5.6))
    dish(f, 680, 460, 190, zone, prog(t, 0.6, 1.4))
    f.text((680, 690), "mold", 26, TEAL, prog(t, 2.0, 2.5), fk="I")
    f.text((880, 260), "a clear ring: the bacteria died", 28, YELLOW, prog(t, 5.4, 6.0), anchor="lm", fk="I") if t < 12.6 else None
    pa = prog(t, 7.2, 7.8)
    if pa > 0:
        f.rect(36, 560, 354, 700, mix(BG, BLUE, 0.1 * pa), r=12, outline=mix(BG, BLUE, pa), w=2)
        f.text((195, 595), "1921: lysozyme,", 26, WHITE, pa); f.text((195, 630), "a germ-killer in mucus", 26, WHITE, pa)
        f.text((195, 665), "years of searching", 24, GREY, pa, fk="I")
        ll = ease(prog(t, 8.0, 9.2))
        if ll > 0: f.dashed((354, 620), (354 + (520 - 354) * ll, 620 - (620 - 520) * ll), mix(BG, BLUE, 0.8), 3)
    ta = prog(t, 12.8, 13.4)
    if ta > 0:
        f.line([(XF(1928), 760), (XF(1945), 760)], GREY, 3)
        for yr in (1928, 1932, 1936, 1940, 1944):
            f.line([(XF(yr), 752), (XF(yr), 768)], GREY, 2); f.text((XF(yr), 795), str(yr), 26, GREY, ta, fk="I")
        Y = 1928 + 17 * ease(prog(t, 13.4, 24.0))
        if Y < 1944.9: f.glow(XF(Y), 760, 6, WHITE)
        notes = [(1929, "paper published, little interest", 13.8, 700), (1940, "Florey and Chain's team, Oxford", 20.6, 700)]
        for yr, lab, ts, y in notes:
            na = prog(t, ts, ts + 0.5)
            if na > 0: f.line([(XF(yr), 750), (XF(yr), y + 20)], mix(BG, GREY, na), 2)
            f.text((XF(yr), y), lab, 24, WHITE, na, fk="I")
        R = 8 + 34 * clamp((Y - 1939.5) / 4)
        f.glow(XF(1928), 560, R * back(prog(t, 13.4, 13.9)), YELLOW)
        f.text((XF(1928) + 60, 490), "what the dish came to mean", 26, YELLOW, prog(t, 22.0, 22.6), anchor="lm", fk="I")
    cap(f, "London, September 1928. Alexander Fleming comes back from holiday to a contaminated dish.", win(t, 0.8, 6.6), y=975, size=36)
    cap(f, "Around a patch of mold, the bacteria have died. He had spent years hunting for germ-killers, so he noticed.", win(t, 6.8, 12.4), y=975, size=36)
    cap(f, "He calls it penicillin and publishes in 1929. For about a decade, little happens.", win(t, 12.6, 18.4), y=975, size=36)
    cap(f, "In 1940, Howard Florey and Ernst Chain's team in Oxford show it can treat infections. It becomes a medicine for millions.", win(t, 18.6, 25.0), y=975, size=36)
    cap(f, "A few days of mold. Its meaning kept growing for years after the moment itself.", prog(t, 25.2, 25.9), y=960, size=40, col=YELLOW)
    f.text((960, 1030), "“Chance favors only the prepared mind.”  Louis Pasteur, 1854", 28, GREY, prog(t, 27.0, 27.7), fk="I")
S_FLEMING = (s_fleming, 32.0)
S_C3 = partcard("Story 3", "Fleming's moldy dish", "a prepared mind, and a meaning that grew")
S_T3 = (tie(3, ["A prepared mind noticed what others might have thrown away.", "And the moment's meaning kept growing long after it was over."],
            "He could not unsee a clear ring around the mold.", ["H6: the past changes how the new is seen", "H3: meaning keeps changing"]), 13.0)

XJ = lambda yr: 300 + (yr - 1971) / 14 * 1400
def s_jobs(t, f):
    story_header(f, "Story 4: Steve Jobs and a calligraphy class")
    pa = prog(t, 0.4, 1.0)
    person(f, 150, 420, 26, GOLD, pa); f.text((150, 482), "Steve Jobs", 30, GOLD, pa)
    ta = prog(t, 0.8, 1.6)
    if ta > 0:
        f.line([(XJ(1971), 700), (XJ(1971) + (XJ(1985) - XJ(1971)) * ease(ta), 700)], GREY, 3)
        for yr in (1972, 1976, 1980, 1984):
            f.line([(XJ(yr), 692), (XJ(yr), 708)], GREY, 2); f.text((XJ(yr), 736), str(yr), 26, GREY, ta, fk="I")
    ca = prog(t, 1.6, 2.2)
    if ca > 0: f.rect(XJ(1972.6), 688, XJ(1973.5), 712, mix(BG, PURPLE, ca), r=5)
    f.text((XJ(1973), 640), "a calligraphy class at Reed", 28, PURPLE, ca, fk="I")
    for k, fk in enumerate(["I", "R", "BI"]):
        f.text((XJ(1972.2) + 80 * k, 520), "Aa", 60, WHITE, prog(t, 2.6 + 0.3 * k, 3.0 + 0.3 * k), fk=fk)
    ga = prog(t, 7.0, 7.6) * (1 - prog(t, 11.4, 12.0))
    f.text(((XJ(1974) + XJ(1983)) / 2, 640), "no practical use, he said", 28, GREY, ga, fk="I")
    ma = prog(t, 12.2, 12.8)
    computer(f, XJ(1984), 430, 110, WHITE, ma)
    for k, fk in enumerate(["S", "R", "I", "M"]):
        f.text((XJ(1984) - 60 + 120 * (k % 2), 360 + 70 * (k // 2)), "Aa", 48, BG, prog(t, 13.2 + 0.4 * k, 13.6 + 0.4 * k), fk=fk)
    f.text((XJ(1984), 640), "the first Macintosh, 1984", 28, WHITE, ma, fk="I")
    arc_p = ease(prog(t, 11.6, 13.2))
    if arc_p > 0:
        arc = bez((XJ(1973), 680), (XJ(1975), 240), (XJ(1981), 240), (XJ(1984) - 120, 380), 50)
        f.line(partial(arc, arc_p), mix(BG, PURPLE, 0.9), 5)
    cap(f, "1972. Steve Jobs drops out of Reed College but keeps dropping in on classes, including calligraphy.", win(t, 0.8, 6.6), y=975, size=36)
    cap(f, "By his own account, it had no practical use in his life.", win(t, 6.8, 11.4), y=975, size=36)
    cap(f, "Ten years later, designing the first Macintosh, it all came back to him.", win(t, 11.6, 17.4), y=975, size=36)
    cap(f, "The Mac launched in 1984 with several typefaces and proportionally spaced letters.", win(t, 17.6, 23.0), y=975, size=36)
    cap(f, "He later said the dots only connect looking backward.", prog(t, 23.2, 23.9), y=960, size=40, col=YELLOW)
    f.text((960, 1030), "As he told it at Stanford in 2005. Xerox PARC's work shaped the Mac's typography too.", 26, GREY, prog(t, 24.6, 25.3), fk="I")
S_JOBS = (s_jobs, 29.0)
S_C4 = partcard("Story 4", "Steve Jobs and a calligraphy class", "a short detour that came back")
S_T4 = (tie(4, ["A short class with no use mattered more ten years later than it did at the time.", "The path came back to it."],
            "He could not unsee good letterforms.", ["H2: duration is not meaning", "H5: one path that comes back"]), 13.0)

def s_pattern(t, f):
    f.text((960, 110), "Four true stories, one pattern", 58, WHITE, write=ease(prog(t, 0.2, 1.3)))
    items = ["A problem he carried turned bathwater into a measurement.", "A similar past made one book say the same thing twice.",
             "A prepared mind noticed; the meaning grew for years.", "A short class came back a decade later."]
    for k, s in enumerate(items):
        y = 280 + 115 * k; a = prog(t, 1.4 + 1.5 * k, 2.0 + 1.5 * k); x = 330
        if k == 0: crown(f, x, y + 8, 34, GOLD, a)
        elif k == 1: book(f, x, y, 32, BLUE, a)
        elif k == 2: dish(f, x, y, 40, 1.0, a)
        else: computer(f, x, y + 8, 32, PURPLE, a)
        f.text((420, y), s, 40, WHITE, a, anchor="lm")
    f.text((960, 790), "Each time, the past did not stay in the past. It became part of how they saw.", 40, WHITE, prog(t, 8.2, 8.9), rise=12)
    f.text((960, 940), "We see what we cannot unsee.", 64, YELLOW, write=ease(prog(t, 10.0, 11.6)))
S_PATTERN = (s_pattern, 16.0)

def s_words(t, f):
    f.text((960, 100), "The whole idea, in one line", 54, WHITE, write=ease(prog(t, 0.2, 1.3)))
    rows = [(1.4, "how strongly something new grabs you", WHITE), (2.4, "=", GREY), (3.0, "how strongly it would grab anyone", BLUE)]
    for k, (ts, s, col) in enumerate(rows): f.text((960, 230 + 75 * k), s, 44 if s != "=" else 54, col, prog(t, ts, ts + 0.6))
    f.row(960, 470, [("+", 54, GREY, "R"), (r"$\gamma$", 72, YELLOW, "R"), (r"$\times$", 54, GREY, "R")], prog(t, 4.2, 4.8), gap=0.5)
    f.text((960, 555), "your similar past that mattered", 44, GOLD, prog(t, 5.0, 5.6))
    f.row(960, 680, [("In all four stories,", 40, WHITE, "R"), (r"$\gamma>0$.", 46, YELLOW, "R")], prog(t, 7.0, 7.7), gap=0.3)
    f.text((960, 790), "But history remembers the hits. Many prepared minds saw nothing, and nobody wrote that down.", 34, GREY, prog(t, 9.4, 10.1), fk="I")
    f.row(960, 880, [("So", 40, WHITE, "R"), (r"$\gamma$", 50, YELLOW, "R"), ("has to be measured in ordinary lives, not read off famous ones.", 40, WHITE, "R")], prog(t, 11.6, 12.3), gap=0.3)
S_WORDS = (s_words, 18.0)

def s_end(t, f):
    f.text((960, 300), "We see what we cannot unsee.", 88, WHITE, write=ease(prog(t, 0.2, 1.6)))
    a = prog(t, 2.0, 2.6)
    f.text((960, 480), "Sources: Vitruvius, On Architecture, Book IX; Darwin, Autobiography; Wallace's 1858 essay;", 28, GREY, a, fk="I")
    f.text((960, 525), "Fleming (1929); Steve Jobs, Stanford commencement address (2005).", 28, GREY, a, fk="I")
    f.text((960, 650), "Idea: Roddsi        Stories and animation: Claude", 36, WHITE, prog(t, 3.2, 3.8))
    f.text((960, 770), "For the full argument, the mathematics and the evidence, see the full video.", 30, GREY, prog(t, 4.4, 5.0), fk="I")
S_END = (s_end, 11.0)

SCENES = [S_OPEN, S_C1, S_ARCH, S_T1, S_C2, S_DW, S_T2, S_C3, S_FLEMING, S_T3, S_C4, S_JOBS, S_T4, S_PATTERN, S_WORDS, S_END]

def frame(i, t):
    fn, dur = SCENES[i]; f = Frame(); fn(t, f)
    fade = min(1.0, t / 0.4, (dur - t) / 0.4) if i > 0 else min(1.0, (dur - t) / 0.4)
    return f.finish(max(fade, 0.0))

if __name__ == "__main__":
    mode = sys.argv[1]
    if mode == "list":
        tot = 0
        for i, (fn, d) in enumerate(SCENES): print(i, fn.__name__, d, round(tot, 1)); tot += d
        print("total", tot)
    elif mode == "still":
        for spec in sys.argv[2].split(","):
            i, tt = spec.split(":"); frame(int(i), float(tt)).save(f"{sys.argv[3]}/fa{int(i):02d}_{float(tt):05.1f}.png")
    elif mode == "render":
        i = int(sys.argv[2]); outdir = sys.argv[3]; fn, dur = SCENES[i]
        tmp = os.path.join(outdir, f"scene{i:02d}.part.mp4"); final = os.path.join(outdir, f"scene{i:02d}.mp4")
        cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
               "-c:v", "libx264", "-crf", "18", "-preset", "veryfast", "-pix_fmt", "yuv420p", "-r", str(FPS), tmp]
        pr = subprocess.Popen(cmd, stdin=subprocess.PIPE)
        for k in range(int(round(dur * FPS))): pr.stdin.write(frame(i, k / FPS).tobytes())
        pr.stdin.close()
        if pr.wait() == 0: os.replace(tmp, final)
        else: sys.exit(1)
