#!/usr/bin/env bash
# Render one of the videos scene by scene, then join the scenes without re-encoding.
# Usage: ./render_all.sh <long|famous|stories|explainer> <output.mp4> [parallel jobs, default 2]
set -euo pipefail
NAME=$1
OUT=$(realpath -m "$2")
JOBS=${3:-2}
cd "$(dirname "$0")"
TMP=$(mktemp -d)
N=$(python3 "$NAME.py" list | grep -vc '^total')
echo "Rendering $N scenes of $NAME.py into $TMP"
seq 0 $((N - 1)) | xargs -P "$JOBS" -I{} python3 "$NAME.py" render {} "$TMP"
for i in $(seq 0 $((N - 1))); do printf "file '%s/scene%02d.mp4'\n" "$TMP" "$i"; done > "$TMP/list.txt"
ffmpeg -y -loglevel error -f concat -safe 0 -i "$TMP/list.txt" -c copy -movflags +faststart "$OUT"
echo "Wrote $OUT"
