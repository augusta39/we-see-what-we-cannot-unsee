# Video code

Every frame is drawn in Python and piped straight into ffmpeg, in the visual style of 3Blue1Brown. Code and animation by Claude (Anthropic).

| Script | Video | Length |
|---|---|---|
| `long.py` | The full explainer: idea and assumptions, then the math and the pyramid, then the evidence | 9:16 |
| `famous.py` | True stories (Archimedes, Darwin and Wallace, Fleming, Jobs) tied back to the idea | 4:13 |
| `stories.py` | Four made-up everyday stories, an earlier companion | 4:21 |
| `explainer.py` | The short version, ending on γ; also the drawing framework the others import | 1:55 |

`long.py` pulls its scenes from `lv_part1.py`, `lv_part2.py`, `lv_part3.py` and `lv_pyr.py` (the pyramid), with shared helpers in `lv_common.py`. On-screen statistics were copied from the JSON results in `../analysis/` and checked against them.

## Requirements

- Python 3 with numpy, Pillow and matplotlib
- ffmpeg with libx264
- Latin Modern fonts (`fonts-lmodern` or TeX Live's `lm` package). The code looks in `/usr/share/texmf/fonts/opentype/public/lm/`; set `LM_FONT_DIR` if yours are elsewhere.

## Usage

```bash
python3 long.py list                      # scenes, durations, start times
python3 long.py still 9 10.0 frame.png    # one frame: scene 9 at 10 s
python3 long.py render 9 out/             # one scene as out/scene09.mp4
./render_all.sh long full.mp4 4           # whole video, 4 scenes at a time
```

Output is 1920x1080 at 30 fps, H.264 (crf 18). The full video takes a while to render on a laptop; parallel jobs help.
