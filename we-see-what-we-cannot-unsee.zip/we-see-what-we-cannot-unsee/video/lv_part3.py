"""Part 3 (evidence) and the closing. Written by Claude. Every number here comes from
analysis/audit_output.json, analysis/attention_results.json,
analysis/drawing_claims_results.json, analysis/h6_results_v2.json and analysis/power_results.json."""
from lv_common import *
from lv_part1 import partcard

S_P3 = partcard("Part 3", "The evidence", "what existing data can say, and what it cannot")

def s_method(t, f):
    header(f, P3H); title(f, t, "How the evidence was checked")
    rows = [(1.2, "Four existing datasets that measured the same people more than once."),
            (3.2, "Each person is compared with themselves over time, so stable differences between people drop out."),
            (5.4, "Each effect comes with a 95% range. If the range crosses zero, we cannot tell the effect from nothing.")]
    for k, (ts, s) in enumerate(rows):
        y = 290 + 140 * k; r = 28 * back(prog(t, ts, ts + 0.5))
        f.circle(250, y, r, outline=BLUE, w=4); f.text((250, y), str(k + 1), 34, BLUE, prog(t, ts + 0.2, ts + 0.6), fk="B")
        para(f, (320, y), s, 38, WHITE, maxw=1450, anchor="lm", write=ease(prog(t, ts + 0.2, ts + 1.4)))
    a = prog(t, 7.8, 8.5)
    f.text((960, 720), "How to read a number like +0.10:", 36, YELLOW, a)
    f.text((960, 780), "one point higher on the first thing now goes with 0.10 points higher on the second thing later.", 34, WHITE, a)
    cap(f, "Reanalysis code and statistics by Claude.", prog(t, 10.4, 11.0), y=960, size=32, col=GREY, fk="I")
S_METHOD = (s_method, 15.0)

def s_e1(t, f):
    header(f, P3H); title(f, t, "Does significance change after the fact?   (H3)", size=52)
    f.text((960, 200), "Hippocorpus: 1,282 people rated how important a memory was, then again weeks to months later (1,310 memories).", 30, GREY, prog(t, 1.0, 1.6), fk="I")
    cols = [RED] * 26 + [GREEN] * 11 + [DIM] * 63
    for k, c in enumerate(cols):
        r_, c_ = divmod(k, 10); x = 300 + c_ * 52; y = 300 + r_ * 52
        a = prog(t, 1.8 + k * 0.025, 2.2 + k * 0.025)
        if a > 0: f.rect(x, y, x + 44, y + 44, mix(BG, c, a), r=5)
    f.text((1260, 380), "37%", 130, YELLOW, prog(t, 4.6, 5.2), fk="B")
    f.text((1260, 480), "of the ratings moved", 38, WHITE, prog(t, 5.0, 5.5))
    leg = [(RED, "26% went down"), (GREEN, "11% went up"), (DIM, "63% stayed the same")]
    for k, (c, s) in enumerate(leg):
        a = prog(t, 5.6 + 0.3 * k, 6.0 + 0.3 * k); y = 580 + 55 * k
        if a > 0: f.rect(1050, y - 16, 1082, y + 16, mix(BG, c, a), r=4)
        f.text((1100, y), s, 32, WHITE, a, anchor="lm")
    cap(f, "But the two ratings correlate 0.62, and 64% started at the top of the scale, so some of this is noise.", prog(t, 8.0, 8.7), y=880, size=34, col=GREY, fk="I")
    a = prog(t, 10.0, 10.6)
    w = chip_w("H3: supported, modestly", 36); chip(f, 960 - w / 2, 975, "H3: supported, modestly", GREEN, a, size=36)
S_E1 = (s_e1, 14.0)

def s_e2(t, f):
    header(f, P3H); title(f, t, "Do meanings keep changing for years?   (H3)", size=52)
    f.text((960, 200), "MainLife: 123 people told their most important life events twice, about four years apart (531 events).", 30, GREY, prog(t, 1.0, 1.6), fk="I")
    f.text((960, 255), "Outcome: how much each event's meaning changed between the two tellings.", 30, GREY, prog(t, 1.4, 2.0), fk="I")
    rows = [("the event is a decade older", -0.165, -0.280, -0.050, BLUE),
            ("the person is a decade older", 0.031, -0.076, 0.139, GREY),
            ("one point more open (personality)", 0.038, 0.010, 0.067, TEAL)]
    coefplot(f, t, rows, 760, 1300, -0.35, 0.25, 420, 130, 2.4, step=1.8, ticks=[-0.3, -0.2, -0.1, 0, 0.1, 0.2], lab_w=560)
    cap(f, "Memories settle; people don't. Older events change less, older people do not.", prog(t, 9.4, 10.1), y=900, size=38)
    a = prog(t, 11.0, 11.6); w = chip_w("H3: supported", 36); chip(f, 960 - w / 2, 985, "H3: supported", GREEN, a, size=36)
S_E2 = (s_e2, 15.0)

def s_e3(t, f):
    header(f, P3H); title(f, t, "Feeling, getting things done, and meaning   (H4, the z axis)", size=50)
    f.text((960, 200), "Experience sampling: 351 people, about 23 phone prompts each, through the day.", 30, GREY, prog(t, 1.0, 1.6), fk="I")
    rows = [("feeling good now  →  meaning hours later", 0.133, 0.098, 0.168, RED),
            ("getting things done now  →  meaning hours later", 0.019, -0.002, 0.041, GOLD),
            ("getting things done now  →  meaning right now", 0.109, 0.084, 0.134, GREY)]
    coefplot(f, t, rows, 840, 1300, -0.05, 0.20, 390, 140, 2.0, step=1.9, ticks=[0, 0.05, 0.1, 0.15, 0.2], lab_w=720)
    cap(f, "Feeling and meaning are linked, but they are not the same thing.", win(t, 8.6, 12.0), y=880, size=38)
    cap(f, "What gets done and what it comes to mean are different quantities: the z axis is not the dots.", prog(t, 12.2, 12.9), y=880, size=38, col=YELLOW)
    a = prog(t, 13.4, 14.0); s = "H4: supported      the z axis is not meaning: supported"
    w = chip_w(s, 34); chip(f, 960 - w / 2, 985, s, GREEN, a, size=34)
S_E3 = (s_e3, 17.5)

def s_e4(t, f):
    header(f, P3H); title(f, t, "Does significance pull attention?   (H1, and half of H6)", size=50)
    f.text((960, 200), "A goal diary: 247 people who had set a personal goal aside, followed for three months (6,569 pairs of entries).", 30, GREY, prog(t, 1.0, 1.6), fk="I")
    A, B, Cc = (560, 520), (1360, 520), (1360, 790)
    a = prog(t, 1.8, 2.4)
    for (x, y), s, col in ((A, "how much the goal matters", GOLD), (B, "how much you think about it", BLUE), (Cc, "a competing goal you prioritized", GREY)):
        if a > 0: f.rect(x - 250, y - 44, x + 250, y + 44, mix(BG, col, 0.15 * a), r=14, outline=mix(BG, col, a), w=3)
        f.text((x, y), s, 30, col, a)
    top = bez((A[0] + 60, A[1] - 50), (A[0] + 200, A[1] - 210), (B[0] - 200, B[1] - 210), (B[0] - 60, B[1] - 50), 40)
    bot = bez((B[0] - 60, B[1] + 50), (B[0] - 200, B[1] + 170), (A[0] + 200, A[1] + 170), (A[0] + 60, A[1] + 50), 40)
    p1 = ease(prog(t, 3.0, 4.2)); p2 = ease(prog(t, 5.6, 6.8))
    if p1 > 0: seg = partial(top, p1); f.line(seg, GOLD, 5); f.arrow(seg[-2], seg[-1], GOLD, 5, 18) if p1 > 0.97 else None
    if p2 > 0: seg = partial(bot, p2); f.line(seg, BLUE, 5); f.arrow(seg[-2], seg[-1], BLUE, 5, 18) if p2 > 0.97 else None
    f.text((960, 330), "+0.07   [0.03, 0.10]   at the next entry", 32, GOLD, prog(t, 4.0, 4.6))
    f.text((960, 705), "+0.09   [0.06, 0.11]   at the next entry", 32, BLUE, prog(t, 6.6, 7.2))
    p3 = ease(prog(t, 8.2, 9.2))
    if p3 > 0: f.dashed((Cc[0], Cc[1] - 46), (Cc[0], Cc[1] - 46 - (Cc[1] - B[1] - 92) * p3), GREY, 3)
    f.text((Cc[0] + 24, 640), "−0.03   [−0.08, 0.01]", 30, GREY, prog(t, 9.0, 9.6), anchor="lm")
    f.text((Cc[0] + 24, 685), "no clear crowding out", 28, GREY, prog(t, 9.2, 9.8), anchor="lm", fk="I")
    cap(f, "Significance and attention feed each other. This is the closest existing evidence for the attention half of the claim.", prog(t, 10.6, 11.3), y=905, size=34)
    cap(f, "Caveat: goals, not past experiences; thoughts, not hours.", prog(t, 12.4, 13.0), y=990, size=34, col=GREY, fk="I")
S_E4 = (s_e4, 17.0)

def s_e5(t, f):
    header(f, P3H); title(f, t, "Do we come back to what we set aside?   (H5)", size=52)
    f.text((960, 200), "The same goal diary, over its three months.", 30, GREY, prog(t, 1.0, 1.6), fk="I")
    o = (300, 800); xe, yt = 1220, 320
    axes(f, o, xe, yt, ease(prog(t, 1.4, 2.2)))
    f.text((xe, 845), "three months", 30, GREY, prog(t, 2.0, 2.5), anchor="rm", fk="I")
    f.text((320, 300), "points out of 100", 28, GREY, prog(t, 2.0, 2.5), anchor="lm", fk="I")
    Y = lambda v: o[1] - (v - 40) / 40 * (o[1] - 360); X = lambda u: o[0] + 40 + u * (1160 - o[0] - 40)
    lines = [(67.3, 10.6, GOLD, "intending to return", 3.0), (58.3, 4.9, TEAL, "how much the goal matters", 5.0)]
    for mean, drop, col, lab, ts in lines:
        p = ease(prog(t, ts, ts + 1.6)); a_, b_ = (X(0), Y(mean + drop / 2)), (X(1), Y(mean - drop / 2))
        if p > 0: f.line([a_, (a_[0] + (b_[0] - a_[0]) * p, a_[1] + (b_[1] - a_[1]) * p)], col, 6)
        f.text((X(1) + 20, Y(mean - drop / 2)), "−%d points" % round(drop), 32, col, prog(t, ts + 1.4, ts + 1.9), anchor="lm")
        f.text((X(0) + 10, Y(mean + drop / 2) - 34), lab, 30, col, prog(t, ts + 0.3, ts + 0.8), anchor="lm", fk="I")
    f.text((1600, 430), "74%", 110, YELLOW, prog(t, 7.0, 7.6), fk="B")
    para(f, (1600, 540), "still meant to return to the goal they had set aside", 32, WHITE, prog(t, 7.4, 8.0), maxw=420)
    cap(f, "The path does come back. But the way back fades faster than the goal's value does.", prog(t, 9.4, 10.1), y=950, size=38, col=YELLOW)
    f.text((960, 1012), "straight-line trends, centred on each measure's average", 24, GREY, prog(t, 9.8, 10.4), fk="I")
S_E5 = (s_e5, 14.0)

def s_e6(t, f):
    header(f, P3H); title(f, t, "And the central claim?   (H6)", size=56)
    boxes = ["people's own memories (398 people)", "their stories about an imagined new event (1,172)", "a measure: how similar is the new event to their past?", "a check: does the measure match people's own similarity ratings?"]
    for k, s in enumerate(boxes):
        x = 270 + 460 * k; y = 400; ts = 1.2 + 1.3 * k; a = prog(t, ts, ts + 0.5)
        if a > 0: f.rect(x - 200, y - 90, x + 200, y + 90, mix(BG, BLUE, 0.12 * a), r=14, outline=mix(BG, BLUE, a), w=3)
        para(f, (x, y), s, 30, WHITE, a, maxw=360, lh=1.25)
        if k < 3 and a > 0: f.arrow((x + 208, y), (x + 252, y), mix(BG, GREY, a), 3, 12)
    x4 = 270 + 460 * 3; r = 34 * back(prog(t, 6.6, 7.1))
    f.circle(x4, 590, r, outline=RED, w=4)
    if r > 20:
        d = 13; f.line([(x4 - d, 590 - d), (x4 + d, 590 + d)], RED, 5); f.line([(x4 + d, 590 - d), (x4 - d, 590 + d)], RED, 5)
    f.text((x4, 660), "agreement: r = 0.03", 32, RED, prog(t, 7.0, 7.5))
    f.text((x4, 705), "a stricter second try failed in both halves", 26, RED, prog(t, 7.8, 8.3), fk="I")
    cap(f, "The measure failed, so the test could not decide either way.", prog(t, 9.0, 9.7), y=820, size=40)
    cap(f, "The test failed to happen. The idea was not refuted.", prog(t, 10.6, 11.3), y=900, size=44, col=YELLOW)
    a = prog(t, 12.2, 12.8); w = chip_w("H6: untested", 36); chip(f, 960 - w / 2, 985, "H6: untested", YELLOW, a, size=36)
S_E6 = (s_e6, 16.0)

def s_score(t, f):
    header(f, P3H); title(f, t, "Where each hypothesis stands")
    rows = [("H1", "Several pursuits, shifting priorities", "significance and attention feed each other (goal diary)", "supported in part", GREEN),
            ("H2", "Duration is not significance", "not measured directly; getting things done barely builds later meaning", "not yet measured", GREY),
            ("H3", "Significance keeps changing", "ratings move; meanings keep changing for years", "supported", GREEN),
            ("H4", "Feeling is not meaning", "linked over hours, but distinct", "supported", GREEN),
            ("H5", "One nonlinear path", "a way of drawing a life; the way back fades (goal diary)", "a frame, not a test", BLUE),
            ("H6", "The past changes how we see the new", "one attempt; its measure failed, so no verdict yet", "untested", YELLOW)]
    for k, (h, name, ev, st, col) in enumerate(rows):
        ts = 1.2 + 1.2 * k; y = 235 + 112 * k; a = prog(t, ts, ts + 0.5)
        chip(f, 90, y, h, WHITE, a, size=32)
        f.text((200, y - 16), name, 36, WHITE, a, anchor="lm")
        f.text((200, y + 26), ev, 26, GREY, prog(t, ts + 0.2, ts + 0.7), anchor="lm", fk="I")
        chip(f, 1830, y, st, col, prog(t, ts + 0.4, ts + 0.9), size=32, anchor="r")
    cap(f, "The pieces have evidence. The center is still a hypothesis, with a clear way to fail.", prog(t, 9.4, 10.1), y=965, size=40, col=YELLOW)
S_SCORE = (s_score, 15.0)

def s_test(t, f):
    header(f, P3H)
    f.row(960, 105, [("How to measure", 58, WHITE, "R"), (r"$\gamma$", 70, YELLOW, "R")], write=ease(prog(t, 0.2, 1.2)), gap=0.3)
    steps = [(1.4, "Follow the same people every week: about 150 people, for 12 weeks."),
             (3.2, "Each week, ask how much earlier experiences matter now, and log where the hours went."),
             (5.0, "Check: does a change in what the past means predict next week's hours, beyond goals, mood and habits?")]
    for k, (ts, s) in enumerate(steps):
        y = 260 + 130 * k; r = 28 * back(prog(t, ts, ts + 0.5))
        f.circle(250, y, r, outline=BLUE, w=4); f.text((250, y), str(k + 1), 34, BLUE, prog(t, ts + 0.2, ts + 0.6), fk="B")
        para(f, (320, y), s, 38, WHITE, maxw=1450, anchor="lm", write=ease(prog(t, ts + 0.2, ts + 1.4)))
    f.text((960, 650), "In simulation, that design detects a small effect about 85% of the time.", 34, GREY, prog(t, 7.0, 7.6), fk="I")
    f.row(960, 770, [("If yes:", 44, GREEN, "R"), (r"$\gamma>0$,", 48, YELLOW, "R"), ("and the idea holds.", 44, WHITE, "R")], prog(t, 8.6, 9.3), rise=12, gap=0.25)
    f.row(960, 845, [("If no:", 44, RED, "R"), (r"$\gamma=0$,", 48, YELLOW, "R"), ("and this version of the idea is wrong.", 44, WHITE, "R")], prog(t, 9.4, 10.1), rise=12, gap=0.25)
    cap(f, "Simulation by Claude.", prog(t, 10.8, 11.4), y=975, size=28, col=GREY, fk="I")
S_TEST = (s_test, 15.0)

PART3 = [S_P3, S_METHOD, S_E1, S_E2, S_E3, S_E4, S_E5, S_E6, S_SCORE, S_TEST]

S_P4 = partcard("Closing", "Why it matters", "back to the philosophy")
def s_why(t, f):
    header(f, P4H)
    lines = [(0.6, "If meaning followed hours, the advice would be arithmetic:", WHITE, 44),
             (1.8, "give the most hours to what matters most.", WHITE, 44),
             (4.6, "If H6 is right, the experiences we choose do not only fill time.", WHITE, 44),
             (6.0, "They retune the instrument we use to judge every later one.", YELLOW, 44),
             (9.0, "A single afternoon can change what a decade feels like.", WHITE, 44),
             (11.6, "Humility: what feels important now is partly an echo of what mattered before.", GREY, 38),
             (14.0, "Freedom: if the lens is built from experience, new experience can rebuild it.", TEAL, 38)]
    ys = [220, 285, 420, 485, 620, 760, 840]
    for (ts, s, col, sz), y in zip(lines, ys):
        f.text((960, y), s, sz, col, write=ease(prog(t, ts, ts + 1.4)))
S_WHY = (s_why, 20.0)

def s_end3(t, f):
    f.text((960, 260), "We see what we cannot unsee.", 84, WHITE, write=ease(prog(t, 0.2, 1.6)))
    f.row(960, 400, [("The open question: how big is", 52, WHITE, "R"), (r"$\gamma$", 62, YELLOW, "R"), ("?", 52, WHITE, "R")], prog(t, 1.8, 2.5), rise=12, gap=0.2)
    a = prog(t, 3.6, 4.3)
    f.text((960, 600), "Idea and hypotheses: Roddsi", 36, WHITE, a)
    f.text((960, 655), "Analysis, statistics, code and animation: Claude", 36, WHITE, a)
    a2 = prog(t, 5.0, 5.7)
    f.text((960, 820), "Data: Hippocorpus (Sap et al., 2020), MainLife (Peters et al., 2023),", 26, GREY, a2, fk="I")
    f.text((960, 860), "openESM dataset 0058 (Gainey et al.), and a goal-shelving diary study.", 26, GREY, a2, fk="I")
    f.text((960, 920), "Illustrations are conceptual or computed from the model; the charts in Part 3 show reanalysed data.", 26, GREY, a2, fk="I")
S_END3 = (s_end3, 12.0)

CLOSING = [S_P4, S_WHY, S_END3]
